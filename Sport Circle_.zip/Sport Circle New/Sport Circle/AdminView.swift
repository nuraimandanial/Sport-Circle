//
//  AdminView.swift
//  Sport Circle
//
//  Created by kinderBono on 09/12/2023.
//

import SwiftUI

struct AdminView: View {
    @EnvironmentObject var appModel: AppModel
    
    var body: some View {
        TabView(selection: $appModel.selectedTab) {
            AdminHome().tag(0)
                .tabItem { Label(
                    title: { Text("Home") },
                    icon: { Image(systemName: "house") }
                ) }
                .environmentObject(appModel)
                .environmentObject(appModel.home)
            NewsView().tag(1)
                .tabItem { Label(
                    title: { Text("News")},
                    icon: { Image(systemName: "newspaper")}
                ) }
                .environmentObject(appModel)
                .environmentObject(appModel.news)
            AdminCircle().tag(2)
                .tabItem { Label(
                    title: { Text("Circle") },
                    icon: { Image(systemName: "person.3") }
                ) }
                .environmentObject(appModel)
            InboxView().tag(3)
                .tabItem { Label(
                    title: { Text("Inbox") },
                    icon: { Image(systemName: "message") }
                )}
                .environmentObject(appModel)
            ProfileView().tag(4)
                .tabItem { Label(
                    title: { Text("Account") },
                    icon: { Image(systemName: "person.circle") }
                )}
                .environmentObject(appModel)
        }
    }
}

#Preview {
    AdminView()
        .environmentObject(AppModel())
}

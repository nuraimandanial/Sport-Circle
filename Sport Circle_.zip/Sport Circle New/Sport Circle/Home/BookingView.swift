//
//  BookingView.swift
//  Sport Circle
//
//  Created by kinderBono on 30/12/2023.
//

import SwiftUI

struct BookingView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var isAvailable: Bool = false
    
    @Binding var court: Court
    
    @State var selectedDate: Date = .now
    
    @State var selectedSport: String = ""
    @State var selectedSlot: Slot = .nineAM
    
    var availableType: [String] {
        return court.type
    }
    var availableSlot: [Slot] {
        return court.slot
    }
    
    @State var alertAvailable: Bool = false
    @State var alertLogin: Bool = false
    @State var alertMessage: String = ""
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    VStack(spacing: 20) {
                        DatePicker("Select Date", selection: $selectedDate, in: Date()..., displayedComponents: .date)
                            .datePickerStyle(GraphicalDatePickerStyle())
                            .labelsHidden()
                            .environment(\.colorScheme, .light)
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundStyle(.blues)
                                .frame(height: 120)
                            VStack {
                                HStack {
                                    Text("Sports Available")
                                    Spacer()
                                    Picker("", selection: $selectedSport) {
                                        ForEach(availableType, id: \.self) { sport in
                                            Text(sport).tag(sport)
                                        }
                                    }
                                }
                                HStack {
                                    Text("Slot")
                                    Spacer()
                                    Picker("Slot", selection: $selectedSlot) {
                                        ForEach(availableSlot, id: \.self) { slot in
                                            Text(slot.rawValue()).tag(slot)
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal, 20)
                            .foregroundStyle(.whitey)
                        }
                    }
                    .onChange(of: selectedDate) {
                        isAvailable = false
                    }
                    if !isAvailable {
                        Button(action: {
                            checkAvailability()
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                Text("Check Availability")
                                    .foregroundStyle(.whitey)
                            }
                            .padding(.horizontal, 40)
                        })
                        .alert(isPresented: $alertAvailable) {
                            Alert(title: Text("Availability"), message: Text(alertMessage), dismissButton: .default(Text("OK"), action: {
                                if alertMessage == "Slot still available" {
                                    isAvailable = true
                                }
                                alertAvailable = false
                            }))
                        }
                    } else {
                        Button(action: {
                            if !appModel.isLoggedIn {
                                alertLogin = true
                            }
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                Text("Book Now")
                                    .foregroundStyle(.whitey)
                            }
                            .padding(.horizontal, 40)
                        })
                        .alert(isPresented: $alertLogin) {
                            Alert(title: Text(""), message: Text("If you want to continue booking, you are required to log in first."), primaryButton: .cancel(), secondaryButton: .default(Text("Log In"), action: {
                                appModel.goToLogin = true
                            }))
                        }
                    }
                }
                .padding()
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
    
    func checkAvailability() {
        let isSlotAvailable = !appModel.events.bookings.contains { booking in
            return booking.slot == selectedSlot && booking.date == selectedDate
        }
        
        alertMessage = isSlotAvailable ? "Slot still available" : "Slot not available"
        alertAvailable = true
    }
}

#Preview {
    BookingView(court: .constant(.ks))
        .environmentObject(AppModel())
}

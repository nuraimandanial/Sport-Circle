////
//  RewardView.swift
//  Sport Circle
//
//  Created by kinderBono on 26/10/2023.
//

import SwiftUI

struct RewardView: View {
    @EnvironmentObject var appModel: AppModel
    @EnvironmentObject var reward: Reward
    @Environment(\.dismiss) var dismiss
    
    @State private var alert: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .foregroundStyle(.blues)
                            .frame(height: 140)
                        VStack(spacing: 10) {
                            Text("Sports Reward")
                                .foregroundStyle(.oranges)
                                .font(.title2)
                                .bold()
                            Text("Terms: Available for users who make 3 times reservations")
                                .font(.callout)
                                .foregroundStyle(.grays)
                                .multilineTextAlignment(.center)
                            HStack {
                                Spacer()
                                Text("Current Reservations: \(appModel.data.current_user.timesBooked) / 3")
                                    .font(.caption2)
                                    .foregroundStyle(.grays)
                            }
                        }
                        .padding()
                    }
                    .padding(.horizontal)
                    ScrollView {
                        ZStack {
                            Color.whitey.opacity(0.3)
                                .cornerRadius(15)
                            VStack {
                                ForEach(reward.current.indices, id: \.self) { index in
                                    let item = reward.current[index]
                                    HStack(spacing: 20) {
                                        Image(item.type)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50)
                                        VStack(alignment: .leading) {
                                            Text(item.title)
                                                .foregroundStyle(.blues)
                                                .bold()
                                                .frame(width: 120, alignment: .leading)
                                        }
                                        Spacer()
                                        if !appModel.data.current_user.isAdmin {
                                            if appModel.data.current_user.timesBooked >= 3 {
                                                Button(action: {
//                                                    reward.redeem(index: index)
                                                    appModel.data.redeemCoupon()
                                                    alert = true
                                                }, label: {
                                                    ZStack {
                                                        RoundedRectangle(cornerRadius: 10)
                                                            .frame(height: 40)
                                                        Text("Redeem")
                                                            .font(.callout)
                                                            .foregroundStyle(.whitey)
                                                    }
                                                })
                                            } else {
                                                VStack(alignment: .center) {
                                                    Text("Cannot Redeem")
                                                        .foregroundStyle(.red)
                                                        .font(.caption)
                                                        .multilineTextAlignment(.center)
                                                }
                                            }
                                        }
                                    }
                                    .alert(isPresented: $alert) {
                                        Alert(title: Text("Reward Redeemed!"), message: Text("You have successfully redeemed this reward."), dismissButton: .default(Text("OK")))
                                    }
                                    .frame(height: 80)
                                    .padding(.horizontal)
                                }
                            }
                        }
                        .padding([.horizontal, .top])
                        
                        if appModel.data.current_user.isAdmin {
                            ZStack {
                                RoundedRectangle(cornerRadius: 15)
                                    .foregroundStyle(.whitey.opacity(0.3))
                                VStack(spacing: 20) {
                                    HStack {
                                        Text("User Redeemed")
                                            .bold()
                                        Spacer()
                                    }
                                    ForEach(appModel.data.users) { user in
                                        if !user.isAdmin && user.redeemedCoupon != 0 {
                                            HStack {
                                                Text(user.profile.detail.name)
                                                Spacer()
                                                Text("\(user.redeemedCoupon)")
                                            }
                                        }
                                    }
                                }
                                .padding()
                            }
                            .padding(.horizontal)
                        }
                    }
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    RewardView()
        .environmentObject(AppModel())
        .environmentObject(AppModel().reward)
}

// arView.swift

import SwiftUI
import ARKit
import RealityKit

struct courtAR: View {
    @Environment(\.dismiss) var dismiss
    
    @Binding var courtName: String
    var sport: String
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack(spacing: 0) {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    ZStack {
                        if sport == "Futsal" {
                            ARViewFutsal().edgesIgnoringSafeArea(.all)
                                .onAppear {
                                    print(sport)
                                }
                        } else {
                            ARViewContainer().edgesIgnoringSafeArea(.all)
                                .onAppear {
                                    print(sport)
                                }
                        }
                        
                        VStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                    .foregroundStyle(.bieges)
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(.blacky, lineWidth: 1)
                                    .frame(height: 60)
                                Text(courtName + ": " + sport)
                                    .font(.title2)
                                    .bold()
                                    .foregroundStyle(.blues)
                                    .padding(5)
                            }
                            .padding()
                            Spacer()
                        }
                    }
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        let courtARn = try! CourtAR.loadScene()
        
        // Add the anchor to the ARView
        arView.scene.anchors.append(courtARn)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
    }
}

struct ARViewFutsal: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        let courtARn = try! CourtAR.loadScene()
        
        // Add the anchor to the ARView
        arView.scene.anchors.append(courtARn)
        
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
    }
}

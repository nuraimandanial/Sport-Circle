//
//  HomeView.swift
//  Sport Circle
//
//  Created by kinderBono on 24/10/2023.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var appModel: AppModel
    @EnvironmentObject var home: HomeState
    
    var location = Court.courtData.uniqueLocation()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 45)
                            .foregroundStyle(.whitey)
                            .shadow(radius: 10)
                            .ignoresSafeArea()
                        
                        LinearGradient(colors: [.blues, .blues.opacity(0.75), .blues.opacity(0.5), .whitey], startPoint: .top, endPoint: .bottom)
                            .cornerRadius(45)
                            .ignoresSafeArea()
                        
                        VStack {
                            if appModel.isLoggedIn {
                                HStack {
                                    Button(action: {
                                        home.sideMenu = true
                                    }, label: {
                                        Image(systemName: "line.3.horizontal")
                                            .imageScale(.large)
                                    })
                                    Spacer()
                                }
                            }
                            HStack {
                                Image("logo1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200)
                                Button(action: {
                                    appModel.home.reward.toggle()
                                }, label: {
                                    if appModel.data.current_user.timesBooked >= 3 {
                                        BlinkingCrown()
                                    } else {
                                        Image(systemName: "crown.fill")
                                            .imageScale(.large)
                                    }
                                })
                                .navigationDestination(isPresented: $appModel.home.reward) {
                                    RewardView()
                                        .environmentObject(appModel)
                                        .environmentObject(appModel.reward)
                                }
                            }
                            
                            VStack(spacing: 10) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(height: 50)
                                        .foregroundStyle(.blues)
                                    HStack {
                                        Text("Please select an area")
                                            .foregroundStyle(.whitey)
                                        Spacer()
                                        Button(action: { home.selectCourt.toggle() }, label: {
                                            Image(systemName: "mappin.and.ellipse")
                                                .imageScale(.large)
                                        })
                                        .sheet(isPresented: $home.selectCourt) {
                                            VStack {
                                                Text("Please select prefered court")
                                                    .font(.title3)
                                                    .foregroundStyle(.blues)
                                                Picker("", selection: $home.selectedCourt) {
                                                    ForEach(Court.courtData) { court in
                                                        Text(court.branch).tag(court.branch)
                                                    }
                                                }
                                                .frame(height: 100)
                                                .pickerStyle(.wheel)
                                                .onTapGesture {
                                                    home.selectCourt.toggle()
                                                }
                                                .onDisappear {
                                                    if appModel.isLoggedIn {
                                                        home.selectCourtDetail = true
                                                    } else {
                                                        home.courtSelected = true
                                                    }
                                                    if home.courtSelected && home.sportSelected {
                                                        home.courtSport = true
                                                    }
                                                }
                                            }
                                            .presentationDetents([.height(200)])
                                        }
                                        .fullScreenCover(isPresented: $home.selectCourtDetail) {
                                            CourtDetail(court: Binding(get: { Court.courtData.courtInLocation(home.selectedCourt)}, set: {_ in}))
                                                .environmentObject(appModel)
                                        }
                                    }
                                    .padding(10)
                                }
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(height: 50)
                                        .foregroundStyle(.blues)
                                    HStack {
                                        Text("Please choose a sport")
                                            .foregroundStyle(.whitey)
                                        Spacer()
                                        Button(action: { home.selectSport.toggle() }, label: {
                                            Image(systemName: "basketball.fill")
                                                .imageScale(.large)
                                        })
                                        .sheet(isPresented: $home.selectSport) {
                                            VStack {
                                                Text("Please select prefered court")
                                                    .font(.title3)
                                                    .foregroundStyle(.blues)
                                                Picker("", selection: $home.selectedSport) {
                                                    ForEach(Court.courtData.courtInLocation(home.selectedCourt).type, id: \.self) { type in
                                                        Text(type).tag(type)
                                                    }
                                                }
                                                .frame(height: 100)
                                                .pickerStyle(.wheel)
                                                .onTapGesture {
                                                    home.selectSport.toggle()
                                                    home.sportSelected = true
                                                    if home.courtSelected && home.sportSelected {
                                                        home.courtSport = true
                                                    }
                                                }
                                            }
                                            .presentationDetents([.height(200)])
                                        }
                                    }
                                    .padding(10)
                                }
                            }
                            .padding(.horizontal, 40)
                            .padding(.bottom)
                            .sheet(isPresented: $home.courtSport) {
                                BookingView(court: Binding(get: { Court.courtData.courtInLocation(home.selectedCourt)}, set: {_ in}))
                                    .presentationDetents([.height(600)])
                                    .onAppear {
                                        home.courtSelected = false
                                        home.sportSelected = false
                                    }
                                    .onDisappear {
                                        home.courtSport = false
                                    }
                            }
                        }
                        .padding()
                    }
                    .frame(height: 300)
                    
                    VStack {
                        HStack {
                            Text("Announcement")
                                .foregroundStyle(.blues)
                                .font(.title3)
                                .bold()
                            Spacer()
                            Button(action: {
                                appModel.selectedTab = 1
                            }, label: {
                                Text("See All")
                            })
                        }
                        .padding(.horizontal, 20)
                        .padding(.top)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            LazyHGrid(rows: [GridItem()], spacing: 0) {
                                ForEach(appModel.news.news) { news in
                                    Button(action: {
                                        home.selectNews.toggle()
                                        home.selectedNews = news
                                    }, label: {
                                        ZStack {
                                            AsyncImage(url: news.imageURL) { phase in
                                                switch phase {
                                                case .empty:
                                                    if news.image != "" {
                                                        Image(news.image)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 200, height: 120)
                                                            .clipShape(RoundedRectangle(cornerRadius: 10))
                                                    } else {
                                                        Placeholder(type: "Empty Image")
                                                    }
                                                case .success(let image):
                                                    image
                                                case .failure:
                                                    if news.image != "" {
                                                        Image(news.image)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 200, height: 120)
                                                            .clipShape(RoundedRectangle(cornerRadius: 10))
                                                    } else {
                                                        Placeholder(type: "Empty Image")
                                                    }
                                                @unknown default:
                                                    EmptyView()
                                                }
                                            }
                                            VStack {
                                                Spacer()
                                                Text(news.title)
                                                    .foregroundStyle(.whitey)
                                                    .bold()
                                                    .lineLimit(2)
                                                    .shadow(radius: 5)
                                            }
                                            .padding()
                                        }
                                        .frame(width: 200, height: 120)
                                        .padding(.vertical, 5)
                                    })
                                    .fullScreenCover(isPresented: $home.selectNews) {
                                        NewsDetail(news: $home.selectedNews)
                                    }
                                    .padding(.trailing, 10)
                                }
                            }
                            .padding(.leading, 20)
                        }
                        .frame(height: 120)
                        
                        HStack {
                            Text("Athlon de Sport")
                                .foregroundStyle(.blues)
                                .font(.title3)
                                .bold()
                            Spacer()
                        }
                        .padding(.horizontal, 20)
                        .padding(.top)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(Array(location.enumerated()), id: \.element.self) { index, location in
                                    Button(action: {
                                        home.selectedIndex = index
                                        home.selectedLocation = location
                                        home.selectedCourtGallery = Court.courtData.courtInLocation(location)
                                    }, label: {
                                        LocationTab(isActive: home.selectedIndex == index, text: location)
                                    })
                                }
                            }
                            .padding(.leading, 20)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(home.selectedCourtGallery.gallery) { gallery in
                                    Group {
                                        if gallery.image != "" {
                                            Image(gallery.image)
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 180, height: 120)
                                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                        } else {
                                            Placeholder(type: "Empty Image")
                                        }
                                    }
                                    .frame(width: 180, height: 120)
                                }
                            }
                            .padding(.leading, 20)
                        }
                        .frame(height: 120)
                    }
                    
                    Spacer()
                }
                .overlay {
                    if home.sideMenu {
                        Color.grays.opacity(0.5).ignoresSafeArea()
                            .onTapGesture {
                                home.sideMenu = false
                            }
                    }
                }
                
                if home.sideMenu {
                    VStack {
                        HStack {
                            ZStack {
                                SideMenu()
                                    .environmentObject(appModel)
                                    .environmentObject(home)
                                    .padding()
                                    .foregroundStyle(.whitey)
                            }
                            .background(.blues)
                            Spacer()
                        }
                        Spacer()
                    }
                }
            }
            .navigationBarBackButtonHidden()
        }
    }
}

struct LocationTab: View {
    var isActive: Bool
    var text: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(text)
                .font(.body)
                .foregroundStyle(isActive ? .blues : .grays)
            if isActive {
                Color.oranges
                    .frame(width: 15, height: 2)
            }
        }
    }
}

struct BlinkingCrown: View {
    @State var isBlinking: Bool = false
    
    var body: some View {
        Image(systemName: "crown.fill")
            .imageScale(.large)
            .foregroundStyle(.oranges)
            .opacity(isBlinking ? 0.5 : 1)
            .onAppear {
                withAnimation(Animation.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                    self.isBlinking = true
                }
            }
            .onDisappear {
                withAnimation {
                    self.isBlinking = false
                }
            }
    }
}

#Preview {
    UserView()
        .environmentObject(AppModel())
}

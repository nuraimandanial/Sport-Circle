//
//  CourtDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 31/12/2023.
//

import SwiftUI

struct CourtDetail: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var court: Court
    
    @State var selectedSport: String = "Badminton"
    @State var goAR: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Button(action: { dismiss() }, label: {
                        Image(systemName: "xmark")
                            .imageScale(.large)
                            .foregroundStyle(.oranges)
                    })
                    
                    if court.image != "" {
                        Image(court.image)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 200)
                    } else {
                        Placeholder(type: "Rectangle Image", height: 200)
                    }
                    
                    VStack(spacing: 0) {
                        Text(court.name)
                            .font(.title2)
                            .bold()
                            .padding(.bottom)
                        Divider()
                        ScrollView {
                            VStack(spacing: 0) {
                                Divider()
                                HStack(alignment: .top, spacing: 10) {
                                    HStack(alignment: .center) {
                                        VStack {
                                            Image(systemName: "person.3")
                                            Text("Host")
                                                .font(.caption)
                                        }
                                        Text(court.branch)
                                            .font(.callout)
                                    }
                                    .padding(10)
                                    Divider()
                                    HStack(alignment: .top) {
                                        VStack {
                                            Image(systemName: "mappin")
                                            Text("Address")
                                                .font(.caption)
                                        }
                                        Text(court.address)
                                            .font(.caption)
                                            .multilineTextAlignment(.leading)
                                    }
                                    .padding(10)
                                }
                                Divider()
                                HStack(alignment: .top, spacing: 10) {
                                    HStack(alignment: .top) {
                                        VStack {
                                            Image(systemName: "calendar.badge.clock")
                                            Text("Slot")
                                                .font(.caption2)
                                        }
                                        VStack(alignment: .leading) {
                                            LazyHGrid(rows: [GridItem(), GridItem(), GridItem()]) {
                                                ForEach(court.slot.indices, id: \.self) { index in
                                                    let slot = court.slot[index]
                                                    VStack(alignment: .leading) {
                                                        Text("Slot \(index + 1)")
                                                            .bold()
                                                        Text(slot.rawValue())
                                                    }
                                                    .font(.caption2)
                                                }
                                            }
                                        }
                                    }
                                    .padding(10)
                                    Divider()
                                    HStack(alignment: .top) {
                                        VStack {
                                            Image(systemName: "building.2")
                                            Text("Facilities")
                                                .font(.caption)
                                        }
                                        VStack(alignment: .leading) {
                                            ForEach(court.facilities, id: \.self) { fac in
                                                HStack(alignment: .top, spacing: 0) {
                                                    Text("・")
                                                    Text(fac)
                                                        .multilineTextAlignment(.leading)
                                                }
                                                .font(.caption2)
                                            }
                                        }
                                    }
                                    .padding(10)
                                }
                                .frame(minHeight: 80)
                                Divider()
                                Text("RM70 per slot")
                                    .font(.caption)
                                    .padding(10)
                                Divider()
                            }
                        }
                        VStack {
                            Button(action: {
                                goAR.toggle()
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.oranges)
                                        .frame(height: 60)
                                    Text("Go AR")
                                        .foregroundStyle(.whitey)
                                    HStack {
                                        Spacer()
                                        Picker("", selection: $selectedSport) {
                                            ForEach(court.type, id: \.self) { sport in
                                                Text(sport).tag(sport)
                                            }
                                        }
                                        .pickerStyle(.menu)
                                        .foregroundStyle(.blues)
                                        .environment(\.colorScheme, .light)
                                    }.padding(.horizontal)
                                    HStack {
                                        Spacer()
                                        Image(systemName: "arrowtriangle.down.fill")
                                            .imageScale(.small)
                                    }.padding(.horizontal, 28)
                                }
                            })
                            .padding(.horizontal)
                            .navigationDestination(isPresented: $goAR) {
                                courtAR(courtName: Binding(get: { court.name }, set: {_ in}), sport: selectedSport)
                            }
                            
                            NavigationLink(destination: {
                                CourtBooking(selectedCourt: court)
                                    .environmentObject(appModel)
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.oranges)
                                        .frame(height: 60)
                                    Text("Book Now")
                                        .foregroundStyle(.whitey)
                                }
                            })
                            .padding(.horizontal)
                        }
                        .padding()
                    }
                    .foregroundStyle(.blues)
                }
                .padding(.vertical)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    CourtDetail(court: .constant(.sb))
        .environmentObject(AppModel())
}

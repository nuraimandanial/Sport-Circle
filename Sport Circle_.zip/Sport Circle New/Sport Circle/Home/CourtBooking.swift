//
//  CourtBooking.swift
//  Sport Circle
//
//  Created by kinderBono on 09/12/2023.
//

import SwiftUI

struct CourtBooking: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var booking: Booking = .init()
    @State var capacity: String = ""
    
    @State var alert: Bool = false
    
    @State var selectedCourt: Court = Court.courtData[0]
    var availableType: [String] {
        return selectedCourt.type
    }
    var availableSlot: [Slot] {
        return selectedCourt.slot
    }
    @State var useCoupon: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    HStack {
                        Text("Court Booking")
                            .font(.title2)
                            .bold()
                        Spacer()
                    }
                    .padding()
                    
                    Form {
                        Section("Booking Details") {
                            Picker("Select Sport", selection: $booking.type) {
                                ForEach(availableType, id: \.self) { type in
                                    Text(type).tag(type)
                                }
                            }
                            .pickerStyle(.segmented)
                            Picker("Court", selection: $selectedCourt) {
                                ForEach(appModel.data.allCourts) { court in
                                    Text(court.name).tag(court)
                                }
                            }
                            DatePicker("Date", selection: $booking.date, in: Date()..., displayedComponents: .date)
                            Picker("Slot", selection: $booking.slot) {
                                ForEach(availableSlot.indices, id: \.self) { index in
                                    let slot = availableSlot[index]
                                    let slotText = "Slot \(index + 1) : \(slot.rawValue())"
                                    Text(slotText).tag(slot)
                                }
                            }
                            TextField("Max Pax", text: $capacity).keyboardType(.numberPad)
                            if appModel.data.current_user.redeemedCoupon != 0 {
                                Toggle(isOn: $useCoupon) {
                                    Text("Use Coupon")
                                }
                            }
                        }
                        .foregroundStyle(.blues)
                        .listRowBackground(Color.whitey.opacity(0.3))
                        
                        Button(action: {
                            createBooking()
                        }, label: {
                            HStack {
                                Spacer()
                                Text("Submit")
                                    .foregroundStyle(.whitey)
                                Spacer()
                            }
                        })
                        .listRowBackground(Color.oranges)
                        .alert(isPresented: $alert) {
                            Alert(title: Text("Booking Confirmed!"), message: useCoupon ? Text("") : Text("Kindly make your payment at the counter."), dismissButton: .default(Text("OK")) {
                                dismiss()
                            })
                        }
                    }
                    .environment(\.colorScheme, .light)
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
        .task {
            booking.court = selectedCourt
        }
    }
    
    func createBooking() {
        booking.profile = appModel.data.current_user.profile
        booking.capacity = (capacity as NSString).integerValue
        booking.date = dateFormat(from: dateString(from: booking.date), set: "dd/MM/yyyy")
        if useCoupon {
            booking.paid = .withCoupon
            appModel.data.useCoupon()
        }
        
        let history = History(date: dateFormat(from: dateString(from: .now), set: "dd/MM/yyyy"), name: appModel.data.current_user.profile.detail.name, court: booking.court, slot: booking.slot, type: booking.type, booking: booking)
        
        print(booking.self)
        appModel.events.createBooking(with: booking)
        appModel.data.addHistory(for: history)
        appModel.data.current_user.timesBooked += 1
        
        alert.toggle()
    }
}

#Preview {
    CourtBooking()
        .environmentObject(AppModel())
}

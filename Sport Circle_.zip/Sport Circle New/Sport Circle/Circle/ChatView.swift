//
//  ChatView.swift
//  Sport Circle
//
//  Created by kinderBono on 05/12/2023.
//

import SwiftUI

struct ChatView: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    var name: String
    @Binding var chat: Chat
    var type: Type
    
    @State var newMessage: String = ""
    @State var loadChat: Chat = .init()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: { dismiss() }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Text(name)
                        .font(.title2)
                        .bold()
                        .padding(10)
                    Divider()
                    
                    ScrollViewReader { scroll in
                        ScrollView {
                            ForEach(loadChat.messages) { message in
                                chatBubble(message)
                                    .padding([.horizontal, .top], 5)
                                    .id(message.id)
                            }
                            .onChange(of: loadChat.messages.count) {
                                scroll.scrollTo(loadChat.messages.last?.id)
                            }
                        }
                    }
                    
                    Divider()
                    HStack(spacing: 15) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.black, lineWidth: 1)
                                .frame(height: 45)
                            TextField("Write a message", text: $newMessage)
                                .padding()
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .onSubmit {
                                    sendMessage()
                                }
                        }
                        Button(action: {
                            sendMessage()
                        }, label: {
                            Text("Send")
                        })
                    }
                    .padding()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
        .task {
            loadChat = chat
        }
    }
    
    func sendMessage() {
        if !newMessage.isEmpty {
            let user = appModel.data.current_user.profile
            let message = Message(sender: user.detail.name, text: newMessage, timestamp: .now)
            loadChat.sendMessage(message)
            
            if type == Type.people {
                if let friend = loadChat.participants.first(where: { $0 != user.id }) {
                    appModel.data.sendMessage(withFriend: friend, message: message)
                }
            } else if type == Type.circle {
                appModel.data.sendMessage(forCircle: chat.id, message: message)
            }
            
            newMessage = ""
        }
    }
    
    func chatBubble(_ message: Message) -> some View {
        var selfMessage: Bool {
            message.sender == appModel.data.current_user.profile.detail.name
        }
        var width: CGFloat {
            let sender = message.sender.count
            let total = (sender != 0 ? sender : 3) + message.time.count
            if total < message.text.count {
                return CGFloat(message.text.count) * 8
            } else if total == message.text.count {
                return CGFloat(total + 2) * 8
            } else {
                return CGFloat(total) * 8
            }
        }
        
        return HStack(spacing: -5) {
            if selfMessage {
                Spacer()
            } else {
                VStack {
                    Spacer()
                    Image(systemName: "arrowtriangle.left.fill")
                        .imageScale(.small)
                        .padding(.bottom, 12)
                        .foregroundStyle(.grays)
                }
            }
            VStack(alignment: .leading) {
                HStack {
                    if !selfMessage {
                        Text(message.sender)
                            .bold()
                    } else {
                        Text("You")
                            .bold()
                    }
                    Spacer()
                    Text(message.time)
                }
                .font(.caption)
                Text(message.text)
                    .font(.callout)
                    .multilineTextAlignment(.leading)
            }
            .foregroundStyle(selfMessage ? .whitey : .whitey)
            .frame(width: width < 200 ? width : 250)
            .padding(10)
            .background(selfMessage ? .oranges : .grays)
            .cornerRadius(10)
            
            if !selfMessage {
                Spacer()
            } else {
                VStack {
                    Spacer()
                    Image(systemName: "arrowtriangle.right.fill")
                        .imageScale(.small)
                        .padding(.bottom, 12)
                        .foregroundStyle(.oranges)
                }
            }
        }
    }
}

#Preview {
    ChatView(name: "Chat", chat: .constant(chats), type: Type.circle)
        .environmentObject(AppModel())
}

enum Type {
    case circle, people
}

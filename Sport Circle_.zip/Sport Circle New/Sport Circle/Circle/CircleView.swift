//
//  CircleView.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct CircleView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var toogleDetail: Bool = false
    @State var circles: [Circles] = []
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(height: 80)
                    
                    HStack {
                        Text("Group")
                            .font(.title2)
                            .bold()
                        Spacer()
                    }
                    .padding()
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        ForEach(circles) { circle in
                            NavigationLink(destination: {
                                CircleDetail(circle: Binding(get: { circle }, set: {_ in}))
                                    .environmentObject(appModel)
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.whitey)
                                    HStack {
                                        Text(circle.name)
                                            .foregroundStyle(.blues)
                                        Spacer()
                                        if circle.image != "" {
                                            Image(circle.image)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 120, height: 80)
                                        } else {
                                            Placeholder(type: "Empty Image")
                                                .frame(width: 120, height: 80)
                                                .clipped()
                                        }
                                    }
                                    .padding(10)
                                }
                                .padding(.bottom, 5)
                            })
                        }
                    }
                    .padding(.horizontal, 40)
                    
                    Spacer()
                }
                .foregroundStyle(.blues)
                .task {
                    circles = appModel.data.allCircles
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    CircleView()
        .environmentObject(AppModel())
}

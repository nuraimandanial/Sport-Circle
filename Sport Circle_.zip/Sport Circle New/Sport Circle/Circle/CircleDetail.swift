//
//  CircleDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 04/12/2023.
//

import SwiftUI

struct CircleDetail: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var circle: Circles
    var isJoined: Bool {
        appModel.data.isJoinedCircle(circle.id)
    }
    @State var participants: String = ""
    
    @State var toggleChat: Bool = false
    @State var chat: Chat = .init()
    
    @State var alert: Bool = false
    @State var leave: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Spacer().frame(height: 80)
                    
                    VStack(spacing: 10) {
                        if circle.image != "" {
                            Image(circle.image)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 150)
                                .clipped()
                        } else {
                            Placeholder(type: "Empty Image")
                                .frame(height: 150)
                                .clipped()
                        }
                        Text(circle.name)
                            .font(.title3)
                            .bold()
                        Text(circle.description)
                        HStack {
                            Text("Participants:")
                                .bold()
                            Text("\(appModel.data.getCircle(for: circle.id).chat.participants.count) / \(circle.capacity)")
                                .id(alert || leave)
                        }
                        
                        VStack(spacing: 10) {
                            if appModel.data.current_user.isAdmin {
                                NavigationLink(destination: {
                                    ChatView(name: circle.name, chat: Binding(get: { appModel.data.chat(forCircle: circle.id) }, set: {_ in}), type: Type.circle)
                                        .environmentObject(appModel)
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(height: 50)
                                            .foregroundStyle(.oranges)
                                        Text("View Chat")
                                            .foregroundStyle(.whitey)
                                    }
                                })
                                
                                Button(action: {
                                    alert = true
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(height: 50)
                                            .foregroundStyle(.red)
                                        Text("Delete Circle")
                                            .foregroundStyle(.whitey)
                                    }
                                })
                                .alert(isPresented: $alert) {
                                    Alert(title: Text("Are you sure?"), message: Text("Confirm to delete this circle."), primaryButton: .cancel(), secondaryButton: .destructive(Text("Confirm"), action: {
                                        appModel.data.deleteCircle(for: circle.id)
                                        alert = false
                                        dismiss()
                                    }))
                                }
                            } else {
                                if isJoined {
                                    NavigationLink(destination: {
                                        ChatView(name: circle.name, chat: Binding(get: { appModel.data.chat(forCircle: circle.id) }, set: {_ in}), type: Type.circle)
                                            .environmentObject(appModel)
                                    }, label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 10)
                                                .frame(height: 50)
                                                .foregroundStyle(.oranges)
                                            Text("View Chat")
                                                .foregroundStyle(.whitey)
                                        }
                                    })
                                }
                                
                                Button(action: {
                                    if !isJoined {
                                        alert = appModel.data.joinCircle(circle.id)
                                    } else {
                                        leave = true
                                    }
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(height: 50)
                                            .foregroundStyle(isJoined ? .red : .blues)
                                        Text(isJoined ? "Leave Circle" : "Join Circle")
                                            .foregroundStyle(.whitey)
                                    }
                                })
                                .alert(isPresented: $alert) {
                                    Alert(title: Text("Success"), message: Text("You joined \(circle.name)!"))
                                }
                                .alert(isPresented: $leave) {
                                    Alert(title: Text("Confirm to Leave?"), message: Text("Are you sure to leave this circle?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("Confirm"), action: {
                                        appModel.data.leaveCircle(circle.id)
                                        leave = false
                                    }))
                                }
                            }
                        }
                    }
                    .foregroundStyle(.blues)
                    .padding()
                    .padding(.horizontal, 40)
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
            .task {
                //circle = appModel.data.getCircle(for: circle.id)
                participants = String(circle.chat.participants.count)
            }
        }
    }
}

#Preview {
    CircleDetail(circle: .constant(.circles[0]))
        .environmentObject(AppModel())
}

//
//  UserView.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct UserView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var alert: Bool = false
    
    var body: some View {
        TabView(selection: $appModel.selectedTab) {
            HomeView().tag(0)
                .tabItem { Label(
                    title: { Text("Home") },
                    icon: { Image(systemName: "house") }
                )}
                .environmentObject(appModel)
                .environmentObject(appModel.home)
            NewsView().tag(1)
                .tabItem { Label(
                    title: { Text("News") },
                    icon: { Image(systemName: "newspaper") }
                )}
                .environmentObject(appModel.news)
            CircleView().tag(2)
                .tabItem { Label(
                    title: { Text("Circle") },
                    icon: { Image(systemName: "person.3") }
                )}
                .environmentObject(appModel)
                .overlay {
                    if !appModel.isLoggedIn {
                        Color.bieges.ignoresSafeArea()
                    }
                }
                .onAppear {
                    if !appModel.isLoggedIn {
                        alert = true
                    }
                }
            InboxView().tag(3)
                .tabItem { Label(
                    title: { Text("Inbox") },
                    icon: { Image(systemName: "message") }
                )}
                .environmentObject(appModel)
                .overlay {
                    if !appModel.isLoggedIn {
                        Color.bieges.ignoresSafeArea()
                    }
                }
                .onAppear {
                    if !appModel.isLoggedIn {
                        alert = true
                    }
                }
            ProfileView().tag(4)
                .tabItem { Label(
                    title: { Text("Profile") },
                    icon: { Image(systemName: "person.circle") }
                )}
                .environmentObject(appModel)
                .overlay {
                    if !appModel.isLoggedIn {
                        Color.bieges.ignoresSafeArea()
                    }
                }
                .onAppear {
                    if !appModel.isLoggedIn {
                        alert = true
                    }
                }
        }
        .alert(isPresented: $alert) {
            Alert(title: Text("Not Available"), message: Text("If you want to access this tab, you are required to log in first."), primaryButton: .cancel(), secondaryButton: .default(Text("Log In"), action: {
                alert = false
                appModel.goToLogin = true
            }))
        }
    }
}

#Preview {
    UserView()
        .environmentObject(AppModel())
}

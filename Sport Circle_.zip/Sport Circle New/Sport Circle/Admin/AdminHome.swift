//
//  AdminHome.swift
//  Sport Circle
//
//  Created by kinderBono on 09/12/2023.
//

import SwiftUI

struct AdminHome: View {
    @EnvironmentObject var appModel: AppModel
    @EnvironmentObject var home: HomeState
    
    @State var edit: Bool = false
    var location = Court.courtData.uniqueLocation()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 45)
                            .foregroundStyle(.whitey)
                            .shadow(radius: 10)
                            .ignoresSafeArea()
                        
                        LinearGradient(colors: [.blues, .blues.opacity(0.75), .blues.opacity(0.5), .whitey], startPoint: .top, endPoint: .bottom)
                            .cornerRadius(45)
                            .ignoresSafeArea()
                        
                        VStack {
                            if appModel.isLoggedIn {
                                HStack {
                                    Button(action: {
                                        home.sideMenu = true
                                    }, label: {
                                        Image(systemName: "line.3.horizontal")
                                            .imageScale(.large)
                                            .foregroundStyle(.oranges)
                                    })
                                    Spacer()
                                }
                            }
                            Spacer()
                            HStack {
                                Image("logo1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200)
                                Button(action: {
                                    home.reward.toggle()
                                }, label: {
                                    Image(systemName: "crown.fill")
                                        .imageScale(.large)
                                        .foregroundStyle(.oranges)
                                })
                                .navigationDestination(isPresented: $home.reward) {
                                    RewardView()
                                        .environmentObject(appModel)
                                        .environmentObject(appModel.reward)
                                }
                            }
                            
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 200)
                    
                    VStack {
                        HStack {
                            Text("Athlon de Sport")
                                .foregroundStyle(.blues)
                                .font(.title3)
                                .bold()
                            Spacer()
                            Button(action: {
                                edit.toggle()
                            }, label: {
                                Text(edit ? "Cancel" : "Edit")
                                    .foregroundStyle(edit ? .red : .oranges)
                            })
                        }
                        .padding(.horizontal, 20)
                        .padding(.top)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(Array(location.enumerated()), id: \.element.self) { index, location in
                                    Button(action: {
                                        home.selectedIndex = index
                                        home.selectedLocation = location
                                        home.selectedCourtGallery = Court.courtData.courtInLocation(location)
                                    }, label: {
                                        LocationTab(isActive: home.selectedIndex == index, text: location)
                                    })
                                }
                            }
                            .padding(.leading, 20)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(home.selectedCourtGallery.gallery) { gallery in
                                    ZStack {
                                        Group {
                                            if gallery.image != "" {
                                                Image(gallery.image)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .frame(width: 180, height: 120)
                                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                            } else {
                                                Placeholder(type: "Empty Image")
                                            }
                                        }
                                        .frame(width: 180, height: 120)
                                        .padding(5)
                                        
                                        if edit {
                                            HStack(alignment: .top) {
                                                Spacer()
                                                VStack {
                                                    Button(action: {
                                                        
                                                    }, label: {
                                                        Image(systemName: "minus.circle.fill")
                                                            .foregroundStyle(.red)
                                                    })
                                                    Spacer()
                                                }
                                            }
                                        }
                                    }
                                    .frame(width: 190, height: 130)
                                }
                                if edit {
                                    Button(action: {
                                        
                                    }, label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 10)
                                                .foregroundStyle(.grays.opacity(0.1))
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(.grays, style: StrokeStyle(lineWidth: 1, dash: [6]))
                                            Image(systemName: "plus.circle.fill")
                                        }
                                        .frame(width: 180, height: 120)
                                    })
                                }
                            }
                            .padding(.leading, 15)
                        }
                        .frame(height: 120)
                    }
                    
                    Spacer()
                }
                .overlay {
                    if home.sideMenu {
                        Color.grays.opacity(0.5).ignoresSafeArea()
                            .onTapGesture {
                                home.sideMenu = false
                            }
                    }
                }
                
                if home.sideMenu {
                    VStack {
                        HStack {
                            ZStack {
                                SideMenu()
                                    .environmentObject(appModel)
                                    .padding()
                                    .foregroundStyle(.whitey)
                            }
                            .background(.blues)
                            Spacer()
                        }
                        Spacer()
                    }
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    AdminHome()
        .environmentObject(AppModel())
        .environmentObject(AppModel().home)
}

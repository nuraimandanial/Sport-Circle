//
//  BookingList.swift
//  Sport Circle
//
//  Created by kinderBono on 04/01/2024.
//

import SwiftUI

struct BookingList: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var searchText: String = ""
    var filteredList: [Booking] {
        if searchText != "" {
            return appModel.events.bookings.filter { booking in
                return booking.profile.detail.name.localizedCaseInsensitiveContains(searchText)
            }
        } else {
            return appModel.events.bookings
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        HStack {
                            Text("Booking List")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        Divider()
                        SearchBar()
                        
                        ScrollView(.vertical, showsIndicators: false) {
                            ForEach(filteredList.indices, id: \.self) { index in
                                let booking = filteredList[index]
                                
                                NavigationLink(destination: {
                                    BookingDetail(booking: Binding(get: { booking }, set: {_ in}))
                                        .environmentObject(appModel)
                                }, label: {
                                    ZStack {
                                        Rectangle()
                                            .frame(height: 60)
                                            .foregroundStyle(.whitey)
                                        HStack(alignment: .center, spacing: 10) {
                                            Text("\(index + 1).")
                                            Spacer()
                                            VStack {
                                                Text(booking.court.name)
                                                    .bold()
                                                Text(booking.type)
                                                    .foregroundStyle(.grays)
                                            }
                                            .frame(width: 160)
                                            Spacer()
                                            Text(booking.profile.detail.name)
                                        }
                                        .padding(10)
                                    }
                                    .padding(.horizontal)
                                    .foregroundStyle(.blues)
                                })
                            }
                        }
                    }
                    .padding()
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
    
    @ViewBuilder
    func SearchBar() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.whitey)
                .frame(height: 50)
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.grays)
                TextField("Search Booking", text: $searchText)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.grays)
                    })
                }
            }
            .padding(10)
        }
    }
}

#Preview {
    BookingList()
        .environmentObject(AppModel())
}

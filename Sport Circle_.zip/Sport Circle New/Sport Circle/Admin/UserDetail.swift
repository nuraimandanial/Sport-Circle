//
//  UserDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 04/01/2024.
//

import SwiftUI

struct UserDetail: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var profile: Profile
    @State var alert: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        HStack {
                            Text("Registered User Detail")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        Divider()
                        VStack(spacing: 10) {
                            HStack {
                                Text("Name")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(profile.detail.name)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Email")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(profile.email)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Password")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(String(repeating: "*", count: profile.password.count))
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Phone No.")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(profile.detail.phone)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Gender")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(profile.detail.gender)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Birthday Date")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(profile.detail.birthDate.formatted(date: .long, time: .omitted))
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                        }
                        .padding()
                        
                        Button(action: {
                            
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                    .foregroundStyle(.oranges)
                                HStack {
                                    Image(systemName: "square.and.pencil")
                                    Text("Edit")
                                }
                                .foregroundStyle(.whitey)
                            }
                        })
                        .padding(.horizontal, 40)
                        
                        Button(action: {
                            alert = true
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                    .foregroundStyle(.red)
                                HStack {
                                    Image(systemName: "trash")
                                    Text("Delete")
                                }
                                .foregroundStyle(.whitey)
                            }
                        })
                        .padding(.horizontal, 40)
                        .alert(isPresented: $alert) {
                            Alert(title: Text("Confirm Delete?"), message: Text("Are you sure to delete this user?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("Confirm"), action: {
                                appModel.data.deleteUser(for: profile.id)
                                alert = false
                            }))
                        }
                    }
                    .padding()
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    UserDetail(profile: .constant(.admin))
        .environmentObject(AppModel())
}

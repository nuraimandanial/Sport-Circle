//
//  AdminCircle.swift
//  Sport Circle
//
//  Created by kinderBono on 04/01/2024.
//

import SwiftUI

struct AdminCircle: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var allCircles: [Circles] = []
    
    @State var addCircle: Bool = false
    @State var toogleDetail: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(height: 80)
                    
                    HStack {
                        Text("Group")
                            .font(.title2)
                            .bold()
                        Spacer()
                        Button(action: {
                            addCircle = true
                        }, label: {
                            Text("Add New")
                                .foregroundStyle(.oranges)
                        })
                        .navigationDestination(isPresented: $addCircle) {
                            AddCircle()
                                .environmentObject(appModel)
                                .presentationDetents([.height(300)])
                        }
                    }
                    .padding()
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        ForEach(allCircles) { circle in
                            NavigationLink(destination: {
                                CircleDetail(circle: Binding(get: { circle }, set: {_ in}))
                                    .environmentObject(appModel)
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.whitey)
                                    HStack {
                                        Text(circle.name)
                                            .foregroundStyle(.blues)
                                        Spacer()
                                        if circle.image != "" {
                                            Image(circle.image)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 120, height: 80)
                                        } else {
                                            Placeholder(type: "Empty Image")
                                                .frame(width: 120, height: 80)
                                                .clipped()
                                        }
                                    }
                                    .padding(10)
                                }
                                .padding(.bottom, 5)
                            })
                        }
                    }
                    .padding(.horizontal, 40)
                    
                    Spacer()
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
            .task {
                allCircles = appModel.data.allCircles
            }
        }
    }
}

#Preview {
    AdminCircle()
        .environmentObject(AppModel())
}

struct AddCircle: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var circle: Circles = .init()
    @State var capacity: String = ""
    
    @State var success: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Form {
                        Section("Detail") {
                            TextField("Name", text: $circle.name)
                            TextField("Description", text: $circle.description)
                            Picker("Type", selection: $circle.type) {
                                ForEach(Court.init().type, id: \.self) { type in
                                    Text(type).tag(type)
                                }
                            }
                            .environment(\.colorScheme, .light)
                            Picker("Level", selection: $circle.level) {
                                Text(Level.beginner.rawValue()).tag(Level.beginner)
                                Text(Level.intemediate.rawValue()).tag(Level.intemediate)
                                Text(Level.advance.rawValue()).tag(Level.advance)
                            }
                            .environment(\.colorScheme, .light)
                            TextField("Capacity", text: $capacity).keyboardType(.numberPad)
                        }
                        .listRowBackground(Color.whitey.opacity(0.3))
                        
                        Button(action: {
                            appModel.data.addCircle(with: circle)
                            success = true
                        }, label: {
                            HStack {
                                Spacer()
                                Text("Submit")
                                Spacer()
                            }
                        })
                        .alert(isPresented: $success) {
                            Alert(title: Text("Success"), message: Text("Circle created!"), dismissButton: .default(Text("OK"), action: {
                                dismiss()
                            }))
                        }
                        .foregroundStyle(.whitey)
                        .listRowBackground(Color.oranges)
                    }
                    .environment(\.colorScheme, .light)
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationBarBackButtonHidden()
        }
    }
}

//
//  RegisteredUsers.swift
//  Sport Circle
//
//  Created by kinderBono on 09/12/2023.
//

import SwiftUI

struct RegisteredUsers: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var detail: Bool = false
    
    @State var searchText: String = ""
    var filteredList: [User] {
        if searchText != "" {
            let filtered = appModel.data.users.filter { user in
                return user.id != appModel.data.current_user.id && !user.isAdmin &&
                (user.profile.detail.name.localizedCaseInsensitiveContains(searchText))
            }
            return filtered
        } else {
            return appModel.data.users.filter { user in
                return user.id != appModel.data.current_user.id && !user.isAdmin
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        HStack {
                            Text("List of Registered Users")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        Divider()
                        SearchBar()
                        
                        ForEach(filteredList.indices, id: \.self) { index in
                            let profile = filteredList[index].profile
                            
                            NavigationLink(destination: {
                                UserDetail(profile: Binding(get: { profile }, set: {_ in}))
                                    .environmentObject(appModel)
                            }, label: {
                                ZStack {
                                    Rectangle()
                                        .foregroundStyle(.whitey)
                                        .frame(height: 60)
                                    
                                    HStack {
                                        Text("\(index + 1).")
                                        Text(profile.detail.name.isEmpty ? "No Name" : profile.detail.name)
                                            .bold()
                                        Spacer()
                                    }
                                    .padding()
                                }
                                .padding(.horizontal)
                                .foregroundStyle(.blues)
                            })
                        }
                        
                    }.padding()
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
    
    @ViewBuilder
    func SearchBar() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.whitey)
                .frame(height: 50)
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.grays)
                TextField("Search User", text: $searchText)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.grays)
                    })
                }
            }
            .padding(10)
        }
    }
}

#Preview {
    RegisteredUsers()
        .environmentObject(AppModel())
}

//
//  BookingDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 04/01/2024.
//

import SwiftUI

struct BookingDetail: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var booking: Booking
    @State var delete: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        HStack {
                            Text("Booking Detail")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        Divider()
                        VStack(spacing: 10) {
                            HStack {
                                Text("Date")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(booking.date.formatted(date: .abbreviated, time: .omitted))
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Slot")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(booking.slot.rawValue())
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Facility")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(booking.court.name)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Sport")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(booking.type)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                            HStack {
                                Text("Client")
                                    .frame(width: 120, alignment: .leading)
                                Text(":")
                                    .frame(width: 20)
                                Text(booking.profile.detail.name)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                            }
                        }
                        .padding()
                        
                        Button(action: {
                            
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                    .foregroundStyle(.oranges)
                                HStack {
                                    Image(systemName: "square.and.pencil")
                                    Text("Edit")
                                }
                                .foregroundStyle(.whitey)
                            }
                        })
                        .padding(.horizontal, 40)
                        
                        Button(action: {
                            delete = true
                        }, label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(height: 60)
                                    .foregroundStyle(.red)
                                HStack {
                                    Image(systemName: "trash")
                                    Text("Delete")
                                }
                                .foregroundStyle(.whitey)
                            }
                        })
                        .padding(.horizontal, 40)
                        .alert(isPresented: $delete) {
                            Alert(title: Text("Are you sure?"), message: Text("Confirm to delete this booking?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("Confirm"), action: {
                                appModel.events.deleteBooking(for: booking.id)
                                delete = false
                            }))
                        }
                    }
                    .padding()
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    BookingDetail(booking: .constant(Booking.bookData[0]))
        .environmentObject(AppModel())
}

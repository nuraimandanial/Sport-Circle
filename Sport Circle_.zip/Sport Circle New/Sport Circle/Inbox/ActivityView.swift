////
//  ActivityView.swift
//  Sport Circle
//
//  Created by kinderBono on 24/10/2023.
//

import SwiftUI

struct ActivityView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State private var detail: Bool = false
    
    @State private var upcoming: [Activity] = []
    @State var selectedActivity: Activity = .init()
    @State var activityDetail: [String: Bool] = [:]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                ScrollView {
                    HStack {
                        Text("Tournament")
                            .font(.title2)
                            .bold()
                        Spacer()
                    }
                    .padding(.vertical)
                    if upcoming.isEmpty {
                        Text("No upcoming tournament available")
                    }
                    ForEach(upcoming) { activity in
                        ZStack {
                            Rectangle()
                                .stroke(lineWidth: 1)
                            Group {
                                let bind = bindingDetail(activity)
                                if activityDetail[activity.name] ?? false{
                                    ActivityDetail(activity: activity)
                                        .onTapGesture {
                                            bind.wrappedValue.toggle()
                                        }
                                        .padding(10)
                                } else {
                                    Button(action: {
                                        bind.wrappedValue.toggle()
                                    }, label: {
                                        Text(activity.name)
                                    })
                                    .padding(10)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
        .task {
            upcoming = appModel.events.activity.filter { $0.upcoming }
        }
    }
    
    func bindingDetail(_ activity: Activity) -> Binding<Bool> {
        let key = activity.name
        return Binding(get: {
            activityDetail[key] ?? false
        }, set: {
            activityDetail[key] = $0
        })
    }
}

#Preview {
    ActivityView()
        .environmentObject(AppModel())
}

struct ActivityDetail: View {
    var activity: Activity
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if activity.court.image != "" {
                Image(activity.court.image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 120)
            } else {
                Image("logo2")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 120)
            }
            Text("Date: \(activity.date.formatted(date: .abbreviated, time: .omitted))")
            Text(activity.description)
            HStack(alignment: .top) {
                Image(systemName: "phone.circle")
                VStack(alignment: .leading) {
                    Text("Contact Us")
                        .bold()
                    Text(activity.contact)
                        .multilineTextAlignment(.leading)
                }
            }
        }
    }
}

//
//  PeopleView.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct PeopleView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var circles: [Circles] = []
    @State var friends: [User] = []
    
    @State var circleChat: Chat = .init()
    @State var userChat: Chat = .init()
    
    @State var refreshView: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                    .id(refreshView)
                
                ScrollView {
                    HStack {
                        Text("Circles")
                            .font(.title2)
                            .bold()
                        Spacer()
                        Button(action: {
                            appModel.selectedTab = 2
                        }, label: {
                            Text("Join Circle")
                                .foregroundStyle(.oranges)
                        })
                    }
                    .padding(.vertical)
                    if circles.isEmpty {
                        Text("Empty")
                    } else {
                        ForEach(circles) { circle in
                            NavigationLink(destination: {
                                ChatView(name: circle.name, chat: Binding(get: { appModel.data.chat(forCircle: circle.id) }, set: { circleChat = $0 }), type: Type.circle)
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.whitey)
                                    HStack(spacing: 20) {
                                        Group {
                                            if circle.image != "" {
                                                Image(circle.image)
                                                    .resizable()
                                                    .scaledToFit()
                                                    .frame(width: 80, height: 80)
                                                    .clipShape(Circle())
                                            } else {
                                                Placeholder(type: "Empty Image")
                                                    .frame(width: 80, height: 80)
                                                    .clipShape(Circle())
                                            }
                                        }
                                        VStack(alignment: .leading) {
                                            Text(circle.name)
                                                .bold()
                                            if let lastMessage = appModel.data.chat(forCircle:  circle.id).messages.last {
                                                Text("\(messageFormat(lastMessage)): \(lastMessage.text)")
                                                    .multilineTextAlignment(.leading)
                                            } else {
                                                Text(circle.description)
                                                    .multilineTextAlignment(.leading)
                                            }
                                        }
                                        .foregroundStyle(.blues)
                                        Spacer()
                                    }
                                    .padding()
                                }
                            })
                            .padding(.horizontal)
                        }
                    }
                    
                    if !appModel.data.current_user.isAdmin {
                        HStack {
                            Text("Friends")
                                .font(.title2)
                                .bold()
                            Spacer()
                            NavigationLink(destination: {
                                AddFriend()
                                    .environmentObject(appModel)
                            }, label: {
                                Text("Add Friend")
                                    .foregroundStyle(.oranges)
                            })
                        }
                        .padding(.vertical)
                        if friends.isEmpty {
                            Text("No friends")
                        } else {
                            ForEach(friends) { user in
                                let profile = user.profile
                                NavigationLink(destination: {
                                    ChatView(name: profile.detail.name, chat: Binding(get: { appModel.data.chat(withFriend: user.id) }, set: { userChat = $0 }), type: Type.people)
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .foregroundStyle(.whitey)
                                        HStack(spacing: 20) {
                                            Group {
                                                if profile.detail.image != "" {
                                                    Image(profile.detail.image)
                                                        .resizable()
                                                        .scaledToFit()
                                                        .frame(width: 80, height: 80)
                                                        .clipShape(Circle())
                                                } else {
                                                    Placeholder(type: "Empty Image")
                                                        .frame(width: 80, height: 80)
                                                        .clipShape(Circle())
                                                }
                                            }
                                            VStack(alignment: .leading) {
                                                Text(profile.detail.name)
                                                    .bold()
                                                if let lastMessage = appModel.data.chat(withFriend:  profile.id).messages.last {
                                                    Text("\(messageFormat(lastMessage)): \(lastMessage.text)")
                                                        .multilineTextAlignment(.leading)
                                                } else {
                                                    Text(profile.detail.description)
                                                        .multilineTextAlignment(.leading)
                                                }
                                            }
                                            .foregroundStyle(.blues)
                                            Spacer()
                                        }
                                        .padding()
                                    }
                                })
                                .padding(.horizontal)
                            }
                        }
                    }
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
            .onAppear {
                refreshView.toggle()
            }
        }
        .task {
            circles = appModel.data.fetchJoinedCircles()
            friends = appModel.data.fetchFriendsList()
        }
    }
    
    func messageFormat(_ message: Message) -> String {
        if message.sender == appModel.data.current_user.profile.detail.name {
            return "You"
        } else {
            return message.sender
        }
    }
}

#Preview {
    PeopleView()
        .environmentObject(AppModel())
}

//
//  HistoryView.swift
//  Sport Circle
//
//  Created by kinderBono on 04/01/2024.
//

import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    var history: [History] {
//        appModel.data.current_user.history
        [.history, .paid]
    }
    
    @State var selectedHistory: History?
    @State var alert: Bool = false
    @State var status: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    VStack {
                        HStack {
                            Text("History")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        .padding()
                        if history.isEmpty {
                            Text("No history available")
                        }
                        ScrollView {
                            ForEach(history) { history in
                                ZStack {
                                    Rectangle()
                                        .stroke(lineWidth: 1)
                                        .frame(height: history.booking.paid == .yes ? 120 : 170)
                                        .id(alert)
                                    VStack {
                                        HStack {
                                            Text(history.date.formatted(date: .abbreviated, time: .omitted))
                                            Spacer()
                                            Text(history.date.formatted(date: .omitted, time: .shortened))
                                        }
                                        Divider()
                                        Text(history.court.name)
                                            .bold()
                                        Text(history.type)
                                        HStack {
                                            Text(history.booking.date.formatted(date: .abbreviated, time: .omitted))
                                            Text(history.slot.rawValue())
                                        }
                                        if history.booking.paid == .no {
                                            HStack {
                                                Text("Automatically cancel booking if payment not received within 24 hours.")
                                                    .font(.caption2)
                                                    .multilineTextAlignment(.leading)
                                                    .foregroundStyle(.red)
                                                Spacer().frame(width: 30)
                                                Button(action: {
                                                    alert = true
                                                    selectedHistory = history
                                                }, label: {
                                                    ZStack {
                                                        RoundedRectangle(cornerRadius: 10)
                                                            .foregroundStyle(.oranges)
                                                            .frame(width: 120)
                                                        Text("Cancel Booking")
                                                            .font(.caption)
                                                            .foregroundStyle(.whitey)
                                                    }
                                                })
                                                .alert(isPresented: $alert) {
                                                    Alert(title: Text("Cancel Booking"), message: Text("Are you sure to cancel this booking?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("OK"), action: {
                                                        appModel.events.deleteBooking(for: selectedHistory!.booking.id)
                                                        status = appModel.data.cancelBooking(from: selectedHistory!)
                                                        alert = false
                                                    }))
                                                }
                                                .alert(isPresented: $status) {
                                                    Alert(title: Text("Success"), message: Text("Booking cancelled!"), dismissButton: .default(Text("OK")))
                                                }
                                            }
                                        }
                                    }
                                    .padding(10)
                                }
                                .padding(.horizontal)
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    HistoryView()
        .environmentObject(AppModel())
}

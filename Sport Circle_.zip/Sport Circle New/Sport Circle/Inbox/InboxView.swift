//
//  InboxView.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct InboxView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var selectionIndex: Int = 0
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        Picker("", selection: $selectionIndex) {
                            Text("People").tag(0)
                            Text("Activity").tag(1)
                        }
                        .environment(\.colorScheme, .light)
                        .pickerStyle(.segmented)
                        
                        TabView(selection: $selectionIndex) {
                            PeopleView()
                                .tag(0)
                                .environmentObject(appModel)
                            
                            ActivityView()
                                .tag(1)
                                .environmentObject(appModel.events)
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    }
                    .padding()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    InboxView()
        .environmentObject(AppModel())
}

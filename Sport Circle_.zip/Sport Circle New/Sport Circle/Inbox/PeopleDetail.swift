//
//  PeopleDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 06/12/2023.
//

import SwiftUI

struct PeopleDetail: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var profile: Profile
    @State var isFriend: Bool = false
    
    @State var alert: Bool = false
    @State var refreshView: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Spacer().frame(height: 80)
                    
                    VStack(spacing: 20) {
                        if profile.detail.image != "" {
                            Image(profile.detail.image)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 150, height: 150)
                                .clipShape(Circle())
                        } else {
                            Placeholder(type: "Empty Image", height: 150)
                                .frame(width: 150)
                                .clipShape(Circle())
                        }
                        VStack {
                            Text(profile.detail.name)
                                .font(.title3)
                                .bold()
                            Text(profile.detail.address)
                        }
                        HStack {
                            VStack {
                                Text("Gender")
                                    .bold()
                                Text(profile.detail.gender)
                            }
                            Spacer()
                            VStack {
                                Text("Birth Date")
                                    .bold()
                                Text(profile.detail.birthDate.formatted(date: .abbreviated, time: .omitted))
                            }
                        }
                        Text(profile.detail.description)
                            .multilineTextAlignment(.center)
                        
                        VStack(spacing: 10) {
                            if isFriend {
                                NavigationLink(destination: {
                                    ChatView(name: profile.detail.name, chat: Binding(get: { appModel.data.chat(withFriend: profile.id)}, set: {_ in}), type: Type.people)
                                        .environmentObject(appModel)
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(height: 50)
                                            .foregroundStyle(.oranges)
                                        Text("View Chat")
                                            .foregroundStyle(.whitey)
                                    }
                                })
                            }
                            
                            Button(action: {
                                if !isFriend {
                                    alert = appModel.data.addFriend(profile.id)
                                } else {
                                    appModel.data.removeFriend(profile.id)
                                }
                                isFriend = appModel.data.isFriend(profile.id)
                            }, label: {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(height: 50)
                                        .foregroundStyle(isFriend ? .red : .oranges)
                                    Text(isFriend ? "Unfriend" : "Add Friend")
                                        .foregroundStyle(.whitey)
                                }
                            })
                            .alert(isPresented: $alert) {
                                Alert(title: Text("Success"), message: Text(profile.detail.name + " is now added to your friend list!"))
                            }
                        }
                    }
                    .foregroundStyle(.blues)
                    .padding()
                    .padding(.horizontal, 40)
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
        .onAppear {
            isFriend = appModel.data.isFriend(profile.id)
        }
    }
}

#Preview {
    PeopleDetail(profile: .constant(.fit))
        .environmentObject(AppModel())
}

//
//  AddFriend.swift
//  Sport Circle
//
//  Created by kinderBono on 06/12/2023.
//

import SwiftUI

struct AddFriend: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var searchText: String = ""
    var filteredUserList: [Profile] {
        let users = appModel.data.users
            if searchText.isEmpty {
                print(users)
                return users.filter { !$0.isAdmin }.map { $0.profile }
            } else {
                let filteredUsers = users.filter { !$0.isAdmin }.map { $0.profile }.filter {
                    $0.detail.name.localizedCaseInsensitiveContains(searchText)
                }
                print("Filtered User List: \(filteredUsers)")
                return filteredUsers
            }
    }
    
    @State var toggleDetail: Bool = false
    @State var selectedUser: Profile = .init()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    VStack {
                        HStack {
                            Text("Find Friends")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        
                        SearchBar()
                        
                        ScrollView {
                            ForEach(filteredUserList) { profile in
                                if profile != appModel.data.current_user.profile {
                                    Button(action: {
                                        selectedUser = profile
                                        toggleDetail = true
                                    }, label: {
                                        UserItem(profile)
                                    })
                                    .fullScreenCover(isPresented: $toggleDetail) {
                                        PeopleDetail(profile: $selectedUser)
                                            .environmentObject(appModel)
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
    
    @ViewBuilder
    func SearchBar() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.whitey)
                .frame(height: 50)
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.grays)
                TextField("Search User", text: $searchText)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.grays)
                    })
                }
            }
            .padding(10)
        }
    }
    
    func UserItem(_ profile: Profile) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.whitey)
            HStack(spacing: 20) {
                if profile.detail.image != "" {
                    Image(profile.detail.image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80)
                        .clipShape(Circle())
                } else {
                    Placeholder(type: "Empty Image", width: 80, height: 80)
                        .frame(width: 80)
                        .clipShape(Circle())
                }
                Text(profile.detail.name)
                    .foregroundStyle(.blues)
                Spacer()
            }
            .padding(10)
        }
    }
}

#Preview {
    AddFriend()
        .environmentObject(AppModel())
}

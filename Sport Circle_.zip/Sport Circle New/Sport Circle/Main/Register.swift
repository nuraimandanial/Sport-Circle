////
//  Register.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct Register: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @State var profile = Profile()
    @State var rePass: String = ""
    @State var register: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    VStack {
                        Image("logo2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200)
                            .padding()
                        Text("Connect, Book & Play")
                            .font(.body)
                            .bold()
                    }
                    Text("Create New Account")
                        .bold()
                    VStack(spacing: 20) {
                        HStack {
                            Text("Username")
                            Spacer()
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.blues, lineWidth: 1.5)
                                .frame(width: 210, height: 50)
                                .overlay {
                                    TextField("Username", text: $profile.username)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled()
                                        .font(.body)
                                        .padding()
                                }
                        }
                        HStack {
                            Text("Email")
                            Spacer()
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.blues, lineWidth: 1.5)
                                .frame(width: 210, height: 50)
                                .overlay {
                                    TextField("Email", text: $profile.email)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled()
                                        .font(.body)
                                        .padding()
                                }
                        }
                        HStack {
                            Text("Phone")
                            Spacer()
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.blues, lineWidth: 1.5)
                                .frame(width: 210, height: 50)
                                .overlay {
                                    TextField("Phone", text: $profile.detail.phone)
                                        .keyboardType(.numberPad)
                                        .font(.body)
                                        .padding()
                                }
                        }
                        HStack {
                            Text("Password")
                            Spacer()
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.blues, lineWidth: 1.5)
                                .frame(width: 210, height: 50)
                                .overlay {
                                    SecureField("Password", text: $profile.password)
                                        .font(.body)
                                        .padding()
                                }
                        }
                        HStack {
                            Text("Confirm Password")
                                .multilineTextAlignment(.leading)
                                .lineLimit(2)
                                .frame(height: 50)
                            Spacer()
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.blues, lineWidth: 1.5)
                                .frame(width: 210, height: 50)
                                .overlay {
                                    SecureField("Confirm Password", text: $rePass)
                                        .font(.body)
                                        .padding()
                                }
                        }
                    }
                    .padding(.horizontal, 40)
                    VStack(spacing: 20) {
                        Button(action: {
                            if profile.password == rePass && profile.password != "" {
                                appModel.data.createUser(for: profile)
                                register.toggle()
                            }
                        }, label: {
                            RoundedRectangle(cornerRadius: 10)
                                .frame(height: 50)
                                .foregroundStyle(.oranges)
                                .overlay {
                                    Text("Register")
                                        .foregroundStyle(.whitey)
                                        .bold()
                                }
                        })
                        .alert(isPresented: $register) {
                            Alert(title: Text("Success"), message: Text(""), dismissButton: .default(Text("OK"), action: {
                                dismiss()
                            }))
                        }
                        HStack {
                            Text("Already have an Account?")
                            Button(action: { dismiss() }, label: {
                                Text("Log In")
                                    .foregroundStyle(.oranges)
                            })
                            .padding(.horizontal, 5)
                        }
                    }
                    .font(.body)
                    .padding(.horizontal, 40)
                }
                .font(.title3)
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    Register()
        .environmentObject(AppModel())
}

//
//  OnBoardingScreen.swift
//  Sport Circle
//
//  Created by kinderBono on 01/01/2024.
//

import SwiftUI

struct OnBoardingScreen: View {
    @Binding var dismiss: Bool
    
    @State var currentPage: Int = 0
    let wording = [
        "Everything you need for sport right at your fingertips",
        "Only with a mobile phone, users can make reservations online",
        "No friends to play sports with",
        "Interact/explore with new friends",
        "Users can feel the experience of being in a sports center"
    ]
    let onBoardImage = ["ob1", "ob2", "ob3", "ob4", "ob5"]
    
    var body: some View {
        VStack {
            TabView(selection: $currentPage) {
                ForEach(wording.indices, id: \.self) { index in
                    onBoardView(index: index)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
            .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .automatic))
            .ignoresSafeArea()
        }
    }
    
    func onBoardView(index: Int) -> some View {
        GeometryReader { geo in
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Image(onBoardImage[index])
                            .resizable()
                            .scaledToFill()
                            .frame(width: geo.size.width)
                            .ignoresSafeArea()
                        
                        VStack(spacing: 20) {
                            if index == 0 {
                                Image("logo1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 250)
                                Text("Welcome to your sports & fitness community")
                                    .font(.title2)
                                    .fontWeight(.heavy)
                                    .frame(width: 260)
                            }
                            if index != 0 {
                                Spacer()
                            }
                            Text(wording[index])
                                .font(.title3)
                                .bold()
                            if index == wording.count - 1 {
                                Button(action: {
                                    dismiss = false
                                }, label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(height: 60)
                                            .foregroundStyle(.oranges)
                                        Text("Continue")
                                            .foregroundStyle(.whitey)
                                    }
                                })
                            }
                        }
                        .padding(40)
                        .foregroundStyle(.whitey)
                        .multilineTextAlignment(.center)
                    }
                }
            }
        }
    }
}

#Preview {
    OnBoardingScreen(dismiss: .constant(false))
}

//
//  SideMenu.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct SideMenu: View {
    @EnvironmentObject var appModel: AppModel
    @EnvironmentObject var home: HomeState
    
    @State var alert: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading) {
                if appModel.data.current_user.isAdmin {
                    TabButton(title: "Dashboard", image: "rectangle.3.group")
                        .foregroundStyle(.oranges)
                        .onTapGesture {
                            home.sideMenu = false
                        }
                    NavigationLink(destination: {
                        RegisteredUsers()
                            .environmentObject(appModel)
                            .onAppear {
                                home.sideMenu = false
                            }
                    }, label: {
                        TabButton(title: "Registered Client", image: "person")
                    })
                    NavigationLink(destination: {
                        BookingList()
                            .environmentObject(appModel)
                            .onAppear {
                                home.sideMenu = false
                            }
                    }, label: {
                        TabButton(title: "Booking List", image: "calendar")
                    })
                    Button(action: {
                        alert = true
                    }, label: {
                        TabButton(title: "Log Out", image: "figure.walk.arrival")
                    })
                    .alert(isPresented: $alert) {
                        Alert(title: Text(""), message: Text("Are you sure want to log out?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("OK"), action: {
                            logout()
                        }))
                    }
                } else {
                    TabButton(title: "Dashboard", image: "rectangle.3.group")
                        .foregroundStyle(.oranges)
                        .onTapGesture {
                            home.sideMenu = false
                        }
                    NavigationLink(destination: {
                        CourtBooking()
                            .environmentObject(appModel)
                            .onAppear {
                                home.sideMenu = false
                            }
                    }, label: {
                        TabButton(title: "Book Now", image: "calendar")
                    })
                    NavigationLink(destination: {
                        HistoryView()
                            .environmentObject(appModel)
                            .onAppear {
                                home.sideMenu = false
                            }
                    }, label: {
                        TabButton(title: "History", image: "doc.badge.clock")
                    })
                    Button(action: {
                        alert = true
                    }, label: {
                        TabButton(title: "Log Out", image: "figure.walk.arrival")
                    })
                    .alert(isPresented: $alert) {
                        Alert(title: Text(""), message: Text("Are you sure want to log out?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("OK"), action: {
                            logout()
                        }))
                    }
                }
            }
            .navigationBarBackButtonHidden()
        }
        .frame(width: 150, height: 160)
    }
    
    @ViewBuilder
    func TabButton(title: String, image: String) -> some View {
        HStack() {
            Image(systemName: image)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
            Text(title)
                .padding(.horizontal, 5)
        }
    }
    
    func logout() {
        alert = false
        appModel.isLoggedIn = false
        appModel.data.saveAllUser()
        appModel.data.current_user = .init()
        home.sideMenu = false
    }
}

#Preview {
    SideMenu()
        .environmentObject(AppModel())
        .environmentObject(AppModel().home)
}

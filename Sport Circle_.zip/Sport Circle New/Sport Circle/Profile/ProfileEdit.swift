//
//  ProfileEdit.swift
//  Sport Circle
//
//  Created by kinderBono on 09/12/2023.
//

import SwiftUI

struct ProfileEdit: View {
    @EnvironmentObject var appModel: AppModel
    @Environment(\.dismiss) var dismiss
    
    @Binding var editProfile: Profile
    
    @State var alert: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Button(action: {
                                dismiss()
                            }, label: {
                                Image(systemName: "chevron.left")
                                    .foregroundStyle(.oranges)
                            })
                            Spacer()
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Circle()
                        .stroke(.blacky, lineWidth: 1)
                        .frame(width: 120)
                        .overlay {
                            if editProfile.detail.image != "" {
                                Image(editProfile.detail.image)
                                    .resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                            } else {
                                Placeholder(type: "Empty Image")
                                    .clipShape(Circle())
                            }
                        }
                        .padding(.top)
                    
                    Form {
                        Section("Personal Information") {
                            TextField("Name", text: $editProfile.detail.name)
                                .autocorrectionDisabled()
                            TextField("Email", text: $editProfile.email)
                                .autocorrectionDisabled()
                            SecureField("Password", text: $editProfile.password)
                            TextField("Phone Number", text: $editProfile.detail.phone)
                            Picker("Gender", selection: $editProfile.detail.gender) {
                                Text("Male").tag("Male")
                                Text("Female").tag("Female")
                                Text("Undefined").tag("Undefined")
                            }
                            DatePicker("Birth Date", selection: $editProfile.detail.birthDate, displayedComponents: .date)
                        }
                        .listRowBackground(Color.whitey.opacity(0.3))
                        
                        Section("Preferences") {
                            Toggle("Toggle Notification", isOn: $editProfile.detail.notification)
                        }
                        .listRowBackground(Color.whitey.opacity(0.3))
                        
                        Section {
                            Button(action: {
                                alert = appModel.data.updateUser(with: editProfile)
                            }, label: {
                                HStack {
                                    Spacer()
                                    Text("Submit")
                                        .foregroundStyle(.whitey)
                                        .bold()
                                    Spacer()
                                }
                            })
                            .alert(isPresented: $alert) {
                                Alert(title: Text("Success"), message: Text("Profile Updated"), dismissButton: .default(Text("OK"), action: {
                                    dismiss()
                                }))
                            }
                        }
                        .listRowBackground(Color.oranges)
                        .listSectionSpacing(60)
                    }
                    .environment(\.colorScheme, .light)
                    .scrollContentBackground(.hidden)
                    .listSectionSpacing(10)
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    ProfileEdit(editProfile: .constant(.admin))
        .environmentObject(AppModel())
}

//
//  ProfileView.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var appModel: AppModel
    
    @State var profile: Profile = .init()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                        HStack {
                            Spacer()
                            NavigationLink(destination: {
                                ProfileEdit(editProfile: $profile)
                                    .environmentObject(appModel)
                            }, label: {
                                Image(systemName: "square.and.pencil")
                                    .imageScale(.large)
                            })
                        }
                        .foregroundStyle(.oranges)
                        .padding()
                    }
                    .frame(height: 80)
                    
                    Circle()
                        .stroke(.blacky, lineWidth: 1)
                        .frame(width: 120)
                        .overlay {
                            if profile.detail.image != "" {
                                Image(profile.detail.image)
                                    .resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                            } else {
                                Placeholder(type: "Empty Image")
                                    .clipShape(Circle())
                            }
                        }
                        .padding(.top)
                    List {
                        Section("Profile Information") {
                            HStack {
                                Text("Name")
                                Spacer()
                                Text(profile.detail.name)
                                    .bold()
                            }
                            HStack {
                                Text("Email")
                                Spacer()
                                Text(profile.email)
                                    .bold()
                            }
                            HStack {
                                Text("Password")
                                Spacer()
                                Text(String(repeating: "*", count: profile.password.count))
                                    .bold()
                            }
                            HStack {
                                Text("Phone")
                                Spacer()
                                Text(profile.detail.phone)
                                    .bold()
                            }
                            HStack {
                                Text("Gender")
                                Spacer()
                                Text(profile.detail.gender)
                                    .bold()
                            }
                            HStack {
                                Text("Birth Date")
                                Spacer()
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundStyle(.grays.opacity(0.3))
                                        .frame(width: 120)
                                    Text(profile.detail.birthDate.formatted(date: .abbreviated, time: .omitted))
                                        .bold()
                                }
                            }
                        }
                        .foregroundStyle(.blues)
                        .listRowBackground(Color.whitey.opacity(0.3))
                        
                        Section("Preferences") {
                            HStack {
                                Text("Allow Notification")
                                Spacer()
                                ZStack {
                                    Capsule()
                                        .foregroundStyle(profile.detail.notification ? .green : .grays.opacity(0.3))
                                    HStack {
                                        if profile.detail.notification {
                                            Spacer().frame(width: 25)
                                        }
                                        Circle()
                                            .frame(width: 30)
                                            .foregroundStyle(.whitey)
                                        if !profile.detail.notification {
                                            Spacer()
                                            Spacer().frame(width: 25)
                                        }
                                    }
                                    .padding(.horizontal, 3)
                                }
                                .frame(width: 55)
                            }
                        }
                        .foregroundStyle(.blues)
                        .listRowBackground(Color.whitey.opacity(0.3))
                    }
                    .environment(\.colorScheme, .light)
                    .scrollContentBackground(.hidden)
                    .scrollIndicators(.hidden)
                    .listSectionSpacing(10)
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
        .task {
            profile = appModel.data.current_user.profile
        }
    }
    
    func logout() {
        
    }
}

#Preview {
    ProfileView()
        .environmentObject(AppModel())
}

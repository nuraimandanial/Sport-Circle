//
//  NewsView.swift
//  Sport Circle
//
//  Created by kinderBono on 24/10/2023.
//

import SwiftUI

struct NewsView: View {
    @EnvironmentObject var news: News
    
    @State var newsLiked: [String: Bool] = [:]
    @State private var detail: Bool = false
    @State private var selectedNews: NewsData = .previewData[0]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    ZStack {
                        Color.blues.ignoresSafeArea()
                        Image("logo1")
                            .resizable()
                            .scaledToFit()
                    }
                    .frame(height: 80)
                    
                    HStack {
                        Text("News")
                            .font(.title2)
                            .bold()
                        Spacer()
                    }
                    .padding()
                    if news.news.isEmpty {
                        Text("No news available currently")
                    }
                    ScrollView {
                        ForEach(news.news, id: \.title) { news in
                            ZStack {
                                NavigationLink(destination: {
                                    NewsDetail(news: Binding(get: { news }, set: {_ in}))
                                }, label: {
                                    VStack(alignment: .leading, spacing: 5) {
                                        AsyncImage(url: news.imageURL) { phase in
                                            switch phase {
                                            case .empty:
                                                if news.image != "" {
                                                    Image(news.image)
                                                        .resizable()
                                                        .scaledToFill()
                                                        .frame(height: 120)
                                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                                } else {
                                                    Placeholder(type: "Empty Image")
                                                }
                                            case .success(let image):
                                                image
                                            case .failure:
                                                if news.image != "" {
                                                    Image(news.image)
                                                        .resizable()
                                                        .scaledToFill()
                                                        .frame(height: 120)
                                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                                } else {
                                                    Placeholder(type: "Empty Image")
                                                }
                                            @unknown default:
                                                EmptyView()
                                            }
                                        }
                                        Text(news.title)
                                            .font(.headline)
                                            .bold()
                                            .multilineTextAlignment(.leading)
                                        Text(news.captionText)
                                            .font(.caption)
                                            .foregroundStyle(.grays)
                                    }
                                })
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Button(action: {
                                            let bind = bindingLiked(news)
                                            bind.wrappedValue.toggle()
                                        }, label: {
                                            Image(systemName: newsLiked[news.title] == true ? "heart.fill" : "heart")
                                                .foregroundStyle(newsLiked[news.title] == true ? .pink : .grays)
                                                .imageScale(.large)
                                        })
                                    }
                                }
                                .foregroundStyle(.grays)
                            }
                            .padding(.horizontal)
                            .padding(.bottom, 30)
                        }
                        .padding(.horizontal)
                    }
                }
                .foregroundStyle(.blues)
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
    
    func bindingLiked(_ news: NewsData) -> Binding<Bool> {
        let key = news.title
        return Binding(get: {
            newsLiked[key] ?? false
        }, set: {
            newsLiked[key] = $0
        })
    }
}

#Preview {
    NewsView()
        .environmentObject(AppModel().news)
}

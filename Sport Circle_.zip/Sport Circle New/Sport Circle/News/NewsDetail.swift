//
//  NewsDetail.swift
//  Sport Circle
//
//  Created by kinderBono on 25/10/2023.
//

import SwiftUI

struct NewsDetail: View {
    @Environment(\.dismiss) var dismiss
    
    @Binding var news: NewsData
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.bieges.ignoresSafeArea()
                
                VStack {
                    Button(action: {
                        dismiss()
                    }, label: {
                        Image(systemName: "xmark")
                    })
                    .padding(.top, 30)
                    .padding(.bottom, 5)
                    AsyncImage(url: news.imageURL) { phase in
                        switch phase {
                        case .empty:
                            if news.image != "" {
                                Image(news.image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 200)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            } else {
                                Placeholder(type: "Empty Image", height: 200)
                            }
                        case .success(let image):
                            image
                        case .failure:
                            if news.image != "" {
                                Image(news.image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 200)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            } else {
                                Placeholder(type: "Empty Image")
                            }
                        @unknown default:
                            EmptyView()
                        }
                    }
                    .padding()
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("Published On")
                                    .bold()
                                Text(news.publishedAt, style: .date)
                                    .foregroundStyle(.grays)
                            }
                            Spacer()
                        }
                        Text(news.title)
                            .font(.title3)
                            .bold()
                        Text(news.descriptionText)
                            .opacity(0.5)
                    }
                    .foregroundStyle(.blues)
                    .padding(.horizontal, 30)
                    
                    Spacer()
                }
            }
            .navigationBarBackButtonHidden()
            .foregroundStyle(.blacky)
        }
    }
}

#Preview {
    NewsDetail(news: .constant(NewsData.previewData[0]))
}

//
//  Court.swift
//  Sport Circle
//
//  Created by kinderBono on 24/10/2023.
//

import Foundation

class Event: ObservableObject {
    private let firebaseService = FirebaseService()
    
    @Published var courtData: [Court] = []
    @Published var bookings: [Booking] = []
    @Published var activity = Activity.activity
    
    init() {
        courtData = fetchCourt(test: true)
        fetchBooking(test: false) { bookings in
            self.bookings = bookings
        }
        removePastBookings()
    }
    
    func fetchCourt(test: Bool) -> [Court] {
        var all: [Court] = []
        if test {
            all.append(contentsOf: Court.courtData.map { $0.self })
        }
        return all
    }
    
    func fetchBooking(test: Bool, completion: @escaping ([Booking]) -> Void) {
        var all: [Booking] = []
        
        firebaseService.fetchAllBookings { bookings in
            all = bookings
            
            if test {
                all = Booking.bookData
            }
            completion(all)
        }
    }
    
    func createBooking(with new: Booking) {
        bookings.append(new)
        firebaseService.addBooking(new)
    }
    
    func removePastBookings() {
        let currentDate = Date()
        
        bookings = bookings.filter { booking in
            return booking.date >= currentDate
        }
    }
    
    func deleteBooking(for id: UUID) {
        guard let booking = bookings.first(where: { $0.id == id }) else {
            return
        }
        
        bookings.removeAll(where: { $0.id == booking.id })
        firebaseService.deleteBooking(booking) { success in
            if success {
                print("Booking deleted successfully")
            } else {
                print("Failed to delete booking")
            }
        }
    }
}

enum Slot: CaseIterable {
    case nineAM, twelvePM, threePM, sixPM, ninePM
    
    func rawValue() -> String {
        switch self {
        case .nineAM:
            "09:00 - 12:00"
        case .twelvePM:
            "12:00 - 15:00"
        case .threePM:
            "15:00 - 18:00"
        case .sixPM:
            "18:00 - 21:00"
        case .ninePM:
            "21:00 - 00:00"
        }
    }
}

extension Slot: Encodable, Decodable, Hashable {}

struct Activity: Identifiable {
    var id = UUID()
    
    var name: String = "Name"
    var description = "If you are interested in joining, you can contact us at the number listed."
    var contact: String = "012-3456987"
    var type: String = ""
    var date: Date = Date()
    var court: Court = Court()
    var upcoming: Bool {
        let oneHourFromNow = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()
        
        return date >= oneHourFromNow
    }
}

extension Activity: Encodable, Decodable {}

extension Activity {
    static let activity = [
        Activity(name: "Badminton for Sister", type: "Badminton", date: dateFormat(from: "22/08/2024,23:10", set: "dd/MM/yyyy,HH:mm"), court: Court.ks),
        Activity(type: "Futsal", date: dateFormat(from: "23/08/2023,10:50", set: "dd/MM/yyyy,HH:mm"), court: Court.tk),
        Activity(type: "Badminton", date: dateFormat(from: "28/10/2023,19:10", set: "dd/MM/yyyy,HH:mm"), court: Court.tk),
        Activity(name: "Basketball Tournament", type: "Basketball", date: dateFormat(from: "8/12/2023,20:00", set: "dd/MM/yyyy,HH:mm"), court: Court.sb),
        Activity(type: "Swimming", date: dateFormat(from: "29/11/2023,17:00", set: "dd/MM/yyyy,HH:mm"), court: Court.ks),
    ]
}

enum Paid {
    case yes, no, withCoupon
}

extension Paid: Encodable, Decodable, Hashable {}

struct Booking: Identifiable {
    var id = UUID()
    
    var profile: Profile = Profile()
    var court: Court = Court()
    var type: String = ""
    var date: Date = Date()
    var slot: Slot = .nineAM
    var capacity: Int = 0
    var paid: Paid = .no
}

extension Booking: Encodable, Decodable, Hashable {}

extension Booking {
    static let bookData = [
        Booking(profile: .shah, court: .sb, type: Court.sb.type[0], date: dateFormat(from: "05/01/2024", set: "dd/MM/yyyy"), slot: .sixPM),
        Booking(profile: .fit, court: .ks, type: Court.sb.type[2], date: dateFormat(from: "06/01/2024", set: "dd/MM/yyyy"), slot: .ninePM, capacity: 4)
    ]
}

struct History: Identifiable {
    var id = UUID()
    
    var date: Date = Date()
    var name: String = ""
    var court: Court = Court()
    var slot: Slot
    var type: String = ""
    var booking: Booking
}

extension History: Encodable, Decodable, Hashable {}

extension History {
    static let history = History(name: "User", court: .ks, slot: .nineAM, type: "Volleyball", booking: .init())
    static let paid = History(name: "User", court: .ks, slot: .nineAM, type: "Volleyball", booking: .init(paid: .yes))
}

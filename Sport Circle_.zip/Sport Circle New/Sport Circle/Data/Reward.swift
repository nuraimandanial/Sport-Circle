//
//  Reward.swift
//  Sport Circle
//
//  Created by kinderBono on 26/10/2023.
//

import Foundation

class Reward: ObservableObject {
    @Published var current: [RewardData] = RewardData.rewards
    
    func redeem(index: Int) {
        current.remove(at: index)
    }
}

struct RewardData: Identifiable {
    var id = UUID()
    
    var title: String = ""
    var type: String = ""
}

extension RewardData: Encodable, Decodable {}

extension RewardData {
    static let rewards: [RewardData] = [
        RewardData(title: "3 Times Booking + Free 1 Slot Booking", type: "discount"),
//        RewardData(title: "3 Times Booking + Free 1 Slot Booking", type: "discount"),
//        RewardData(title: "3 Times Booking + Free 1 Slot Booking", type: "discount"),
    ]
}

//
//  AppModel.swift
//  Sport Circle
//
//  Created by kinderBono on 01/01/2024.
//

import Foundation
import SwiftUI

class AppModel: ObservableObject {
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false
    @Published var data = DataManager()
    @Published var news = News()
    @Published var events = Event()
    
    @Published var home = HomeState()
    @Published var reward = Reward()
    @Published var selectedTab: Int = 0
    
    @Published var goToLogin: Bool = false
}

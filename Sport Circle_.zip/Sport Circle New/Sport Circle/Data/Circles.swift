//
//  Circles.swift
//  Sport Circle
//
//  Created by kinderBono on 04/12/2023.
//

import Foundation

struct Circles: Identifiable {
    var id: UUID {
        chat.id
    }
    
    var name: String = ""
    var description: String = ""
    var image: String = ""
    var type: String = ""
    var level: Level = .beginner
    var capacity: Int = 100
    
    var chat = Chat()
}

extension Circles {
    static let circles = [
        Circles(name: "Basketball", description: "Beginner/Advance level player", type: "Basketball"),
        Circles(name: "Badminton", description: "Beginner/Advance level player", type: "Badminton"),
        Circles(name: "Futsal Hub", description: "Beginner/Advance level player", type: "Futsal"),
        Circles(name: "Hockey", description: "Beginner/Advance level player", type: "Hockey"),
    ]
}

enum Level: CaseIterable {
    case beginner, intemediate, advance
    
    func rawValue() -> String {
        switch self {
        case .beginner:
            return "Beginner"
        case .intemediate:
            return "Intermediate"
        case .advance:
            return "Advance"
        }
    }
}

struct Chat: Identifiable {
    var id = UUID()
    var participants: [UUID] = []
    var messages: [Message] = []
    
    mutating func sendMessage(_ message: Message) {
        messages.append(message)
    }
}

struct Message: Identifiable {
    var id = UUID()
    
    var sender: String = ""
    var text: String = ""
    var timestamp: Date = .distantPast
    
    var time: String {
        timestamp.formatted(date: .omitted, time: .shortened)
    }
}

extension Circles: Encodable, Decodable, Hashable {}
extension Level: Encodable, Decodable, Hashable {}
extension Chat: Encodable, Decodable, Hashable {}
extension Message: Encodable, Decodable, Hashable {}

let chats = Chat(
    participants: [
        Profile.fit.id,
        Profile(username: "Shazlen").id
    ], messages: [
        Message(sender: "Sakinah", text: "Hello!"),
        Message(sender: "Shazlen", text: "Hi there!"),
        Message(sender: "Sakinah", text: "How are you?"),
        Message(sender: "Shazlen", text: "I'm fine, thanks! Btw, what do you guys want to do this weekend?"),
        Message(sender: "userName", text: "Lets playy!"),
        Message(sender: "Sakinah", text: "Suree", timestamp: Date.now)
    ])

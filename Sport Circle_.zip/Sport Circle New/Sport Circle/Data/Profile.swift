//
//  Profile.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import Foundation

struct User: Identifiable {
    var id: UUID { profile.id }
    var profile: Profile = Profile()
    var timesBooked: Int = 0
    var redeemedCoupon: Int = 0
    
    var friends: [UUID] = []
    var joinedCircles: [UUID] = []
    var chats: [UUID: Chat] = [:]
    
    var history: [History] = []
    
    var isAdmin: Bool = false
}

extension User: Encodable, Decodable, Hashable {}

extension User {
    static let admin = User(profile: .admin, isAdmin: true)
    static let fit = User(profile: .fit)
    static let shah = User(profile: .shah)
}

struct Profile: Identifiable {
    var id = UUID()
    
    var username: String = ""
    var email: String = ""
    var password: String = ""
    
    var detail = Details()
}

struct Details {
    var image: String = ""
    var name: String = ""
    var description: String = ""
    var phone: String = ""
    var address: String = "Malaysia"
    var gender: String = "Undefined"
    
    var birthDate: Date = Date(timeIntervalSince1970: 0)
    var notification: Bool = false
}

extension Profile {
    static let profiles = [admin, fit, shah]
    
    static let admin = Profile(id: UUID(uuidString: "10FFEECC-9F99-000A-F9E9-A9B87CD6E") ?? UUID(), username: "admin", email: "admin@email.com", password: "admin012", detail: Details(name: "Test Admin", description: "Admin Overpowered", phone: "011-23458697", address: "Malaysia", gender: "Undefined", notification: true))
    static let fit = Profile(username: "fitriah", password: "fitri12", detail: Details(name: "Fitriah", description: "Living person", address: "Selangor", gender: "Female"))
    static let shah = Profile(username: "shah", password: "shah1234", detail: Details(name: "Shah", description: "Madah berhelah", address: "Kajang, Selangor", gender: "Male"))
}

extension Profile: Encodable, Decodable, Hashable {}
extension Details: Encodable, Decodable, Hashable {}

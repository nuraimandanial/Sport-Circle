//
//  HomeState.swift
//  Sport Circle
//
//  Created by kinderBono on 01/01/2024.
//

import Foundation

class HomeState: ObservableObject {
    @Published var reward: Bool = false
    
    @Published var sideMenu: Bool = false
    
    @Published var selectCourt: Bool = false
    @Published var selectCourtDetail = false
    @Published var selectedCourt: String = Court.courtData[0].branch
    @Published var selectSport: Bool = false
    @Published var selectedSport: String = Court.courtData[0].type[0]
    
    @Published var courtSelected: Bool = false
    @Published var sportSelected: Bool = false
    @Published var courtSport: Bool = false
    
    @Published var selectNews: Bool = false
    @Published var selectedNews: NewsData = .previewData[0]
    
    @Published var selectedIndex: Int = 0
    @Published var selectedLocation: String = "Kuala Selangor"
    @Published var selectedCourtGallery: Court = .ks
    @Published var locationRefresh: Bool = false
}

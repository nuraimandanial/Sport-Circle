//
//  DataManager.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import Foundation

class DataManager: ObservableObject {
    private let firebaseService = FirebaseService()
    
    @Published var users: [User] = []
    @Published var current_user: User = User() {
        didSet {
            saveCurrentUser()
        }
    }
    
    @Published var allCircles: [Circles] = []
    @Published var allCourts: [Court] = Court.courtData
    
    init() {
        fetchAllUsers(test: false) { users in
            self.users = users
        }
        fetchAllCircles(test: false) { circles in
            self.allCircles = circles
        }
        loadCurrentUser()
    }
    
    private let userDefaults = UserDefaults.standard
    private let currentUserKey = "currentUserKey"
    
    public func saveCurrentUser() {
        do {
            let encodedData = try JSONEncoder().encode(current_user)
            userDefaults.set(encodedData, forKey: currentUserKey)
        } catch {
            print("Error encoding current user: \(error)")
        }
    }
    
    private func loadCurrentUser() {
        guard let savedData = userDefaults.data(forKey: currentUserKey) else {
            return
        }
        
        do {
            let loadedUser = try JSONDecoder().decode(User.self, from: savedData)
            current_user = loadedUser
        } catch {
            print("Error decoding current user: \(error)")
        }
    }
    
    func fetchAllUsers(test: Bool, completion: @escaping ([User]) -> Void) {
        var all: [User] = []
        
        firebaseService.fetchAllUsers { users in
            for user in users {
                if user.profile.email.isEmpty || user.profile.detail.phone.isEmpty {
                    continue
                }
                all.append(user)
                print(user.id.uuidString + " : " + user.profile.email + user.profile.detail.phone)
            }
            
            if test {
                all.append(contentsOf: [User(), User.admin, User.fit, User.shah].map { user in
                    return user
                })
            }
            completion(all)
        }
    }
    
    func saveAllUser() {
        for user in users {
            firebaseService.updateUser(user) { success in
                if success {
                    print("Update User Success!")
                }
            }
        }
    }
    
    func fetchAllCircles(test: Bool, completion: @escaping ([Circles]) -> Void) {
        var all: [Circles] = []
        
        firebaseService.fetchAllCircles { circles in
            for circle in circles {
                all.append(circle)
            }
            
            if test {
                all = Circles.circles
            }
            completion(all)
        }
    }
    
    func fetchFriendsList() -> [User] {
        let friends = current_user.friends.compactMap { id in
            users.first { $0.id == id }
        }
        return friends
    }
    
    func fetchUser(for username: String) -> User? {
        users.first(where: { $0.profile.username == username })
    }
    
    func createUser(for profile: Profile) {
        let user = User(profile: profile)
        users.append(user)
        firebaseService.addUser(user)
    }
    
    func updateUser(with new: Profile) -> Bool {
        if let index = users.firstIndex(where: { $0.profile == current_user.profile }) {
            users[index].profile = new
            current_user.profile = new
            
            var status: Bool = true
            
            firebaseService.updateUser(current_user) { success in
                if success {
                    print("Current user updated in Firestore")
                } else {
                    status = false
                    print("Failed to update user in Firestore")
                }
            }
            return status
        } else {
            return false
        }
    }
    
    func deleteUser(for id: UUID) {
        guard let user = users.first(where: { $0.id == id }) else {
            return
        }
        users.removeAll(where: { $0.id == user.id })
        firebaseService.deleteUser(user) { success in
            if success {
                print("User deleted successfully")
            } else {
                print("Failed to delete user")
            }
        }
    }
    
    func addFriend(_ id: UUID) -> Bool {
        guard var friend = users.first(where: { $0.id == id }) else {
            return false
        }
        
        friend.friends.append(current_user.id)
        current_user.friends.append(friend.id)
        
        associateChat(withFriend: friend.id)
        
        firebaseService.updateMultipleUser([current_user, friend]) { success in
            if success {
                print("Add friend update user success")
            }
        }
        
        return true
    }
    
    func isFriend(_ id: UUID) -> Bool {
        return current_user.friends.contains(id)
    }
    
    func removeFriend(_ id: UUID) {
        guard var friend = fetchFriendsList().first(where: { $0.id == id }) else {
            return
        }
        
        friend.friends.removeAll { $0 == current_user.id }
        current_user.friends.removeAll { $0  == friend.id }
        
        friend.chats.removeValue(forKey: current_user.id)
        current_user.chats.removeValue(forKey: friend.id)
        
        firebaseService.updateMultipleUser([current_user, friend]) { success in
            if success {
                print("Remove friend update success")
            }
        }
    }
    
    func logOut() {
        firebaseService.updateMultipleUser(users, completion: {_ in})
        for circle in allCircles {
            firebaseService.updateCircle(circle, completion: {_ in})
        }
        current_user = User()
    }
    
    func associateChat(withFriend id: UUID) {
        guard var friend = fetchFriendsList().first(where: { $0.id == id }) else {
            return
        }
        
        let message = Message(sender: "System", text: "Friend Added", timestamp: .now)
        let chat = Chat(participants: [current_user.id, friend.id], messages: [])
        current_user.chats[friend.id] = chat
        friend.chats[current_user.id] = chat
        
        sendMessage(withFriend: friend.id, message: message)
    }
    
    func chat(withFriend id: UUID) -> Chat {
        guard let friend = fetchFriendsList().first(where: { $0.id == id }) else {
            return Chat()
        }
        
        guard let exist = current_user.chats[friend.id] else {
            let new = Chat(participants: [current_user.id, friend.id])
            return new
        }
        
        return exist
    }
    
    func chat(forCircle id: UUID) -> Chat {
        guard let circle = current_user.joinedCircles.first(where: { $0 == id }) else {
            return Chat()
        }
        
        guard let exist = current_user.chats[circle] else {
            return allCircles.first(where: { $0.id == circle })?.chat ?? Chat()
        }
        
        return exist
    }
    
    func sendMessage(withFriend id: UUID, message: Message) {
        guard var friend = fetchFriendsList().first(where: { $0.id == id }) else {
            return
        }
        
        var friendChat = chat(withFriend: friend.id)
        friendChat.messages.append(message)
        current_user.chats.updateValue(friendChat, forKey: friend.id)
        friend.chats.updateValue(friendChat, forKey: current_user.id)
        
        firebaseService.updateMultipleUser([current_user, friend]) { success in
            if success {
                print("Add friend update user success")
            }
        }
    }
    
    func sendMessage(forCircle id: UUID, message: Message) {
        guard let circle = allCircles.first(where: { $0.id == id }) else {
            return
        }
        
        var chat = chat(forCircle: circle.id)
        chat.messages.append(message)
        
        current_user.chats.updateValue(chat, forKey: circle.id)
        for id in chat.participants {
            if var participant = users.first(where: { $0.id == id }) {
                participant.chats.updateValue(chat, forKey: circle.id)
                firebaseService.updateUser(participant, completion: {_ in})
            }
        }
        
        if let index = allCircles.firstIndex(where: { $0.id == id }) {
            allCircles.insert(circle, at: index)
        }
        
        firebaseService.updateCircle(circle, completion: {_ in})
    }
    
    func addHistory(for history: History) {
        current_user.history.append(history)
        
        firebaseService.updateUser(current_user) {_ in}
    }
    
    func cancelBooking(from history: History) -> Bool {
        if let index = users.firstIndex(where: { $0.profile == current_user.profile }) {
            current_user.history.removeAll(where: { $0.id == history.id })
            users[index] = current_user
            
            var status = true
            
            firebaseService.updateUser(current_user, completion: { success in
                if !success {
                    status = false
                }
            })
            
            return status
        } else {
            return false
        }
    }
    
    func redeemCoupon() {
        if current_user.timesBooked == 3 {
            current_user.redeemedCoupon += 1
            current_user.timesBooked = 0
        }
    }
    
    func useCoupon() {
        if current_user.redeemedCoupon > 0 {
            current_user.redeemedCoupon -= 1
        }
    }
    
    func fetchJoinedCircles() -> [Circles] {
        let circles = current_user.joinedCircles.compactMap { id in
            allCircles.first { $0.id == id }
        }
        return circles
    }
    
    func joinCircle(_ id: UUID) -> Bool {
        guard var circle = allCircles.first(where: { $0.id == id }) else {
            return false
        }
        
        circle.chat.participants.append(current_user.id)
        current_user.joinedCircles.append(circle.id)
        let message = Message(sender: "System", text: "\(current_user.profile.detail.name) joined into this circle!")
        sendMessage(forCircle: circle.id, message: message)
        
        for id in circle.chat.participants {
            if var participant = users.first(where: { $0.id == id }) {
                if !participant.joinedCircles.contains(circle.id) {
                    participant.joinedCircles.append(circle.id)
                }
                firebaseService.updateUser(participant) {_ in}
            }
        }
        
        if let index = allCircles.firstIndex(where: { $0.id == circle.id }) {
            allCircles.remove(at: index)
            allCircles.append(circle)
        }
        
        firebaseService.updateCircle(circle, completion: {_ in})
        
        return true
    }
    
    func isJoinedCircle(_ id: UUID) -> Bool {
        return current_user.joinedCircles.contains(id)
    }
    
    func leaveCircle(_ id: UUID) {
        guard var circle = allCircles.first(where: { $0.id == id }) else {
            return
        }
        
        circle.chat.participants.removeAll { $0 == current_user.id }
        current_user.joinedCircles.removeAll { $0 == circle.id }
        let message = Message(sender: "System", text: "\(current_user.profile.detail.name) leaved from this circle!")
        sendMessage(forCircle: circle.id, message: message)
        
        if let index = allCircles.firstIndex(where: { $0.id == circle.id }) {
            allCircles.remove(at: index)
            allCircles.append(circle)
        }
        
        firebaseService.updateCircle(circle, completion: {_ in})
    }
    
    func addCircle(with new: Circles) {
        allCircles.append(new)
        firebaseService.addCircle(new)
    }
    
    func getCircle(for id: UUID) -> Circles {
        guard let circle = allCircles.first(where: { $0.id == id }) else {
            return .init()
        }
        
        return circle
    }
    
    func deleteCircle(for id: UUID) {
        guard let circle = allCircles.first(where: { $0.id == id }) else {
            return
        }
        
        allCircles.removeAll(where: { $0.id == circle.id })
        firebaseService.deleteCircle(circle) { success in
            if success {
                print("Circle deleted successfully")
            } else {
                print("Failed to delete circle")
            }
        }
    }
}

func dateString(from date: Date, set format: String = "dd MMM yyyy") -> String {
    let df = DateFormatter()
    df.dateFormat = format
    df.timeZone = TimeZone(identifier: "Asia/Kuala_Lumpur")
    return df.string(from: date)
}

func dateFormat(from string: String, set format: String = "dd MMM yyyy") -> Date {
    let df = DateFormatter()
    df.dateFormat = format
    df.timeZone = TimeZone(identifier: "Asia/Kuala_Lumpur")
    if let date = df.date(from: string) {
        return date
    } else {
        return Date()
    }
}

func setTime(_ hour: Int, _ minutes: Int) -> Date {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = TimeZone(identifier: "Asia/Kuala_Lumpur")!
    return calendar.date(bySettingHour: hour, minute: minutes, second: 0, of: Date())!
}

//
//  Court.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import Foundation

struct Court: Identifiable {
    var id = UUID()
    
    var name: String = ""
    var host: String = "Athlon de Sport"
    var branch: String = ""
    var address: String = ""
    var image: String = ""
    
    var slot: [Slot] = [.nineAM, .twelvePM, .threePM, .sixPM, .ninePM]
    var type: [String] = ["Netball", "Futsal", "Volleyball", "Handball"]
    var facilities: [String] = ["Toilet", "Surau", "Changing Room", "Locker", "Food Outlets"]
    
    var gallery: [Gallery] = []
}

extension Court: Encodable, Decodable, Hashable {}

extension Court {
    static let courtData = [ks]
    
    static let ks = Court(name: "ADS Kuala Selangor", branch: "Kuala Selangor", address: "Pusat Komuniti Kuala Selangor", image: "", gallery: [Gallery(image: "gal_1"), Gallery(image: "gal_2")])
    static let tk = Court(name: "ADS Tanjung Karang", branch: "Tanjung Karang", address: "Kompleks Sukan Tanjung Karang", image: "", gallery: [Gallery(image: "gal_1"), Gallery(image: "gal_3"), Gallery(image: "gal_2")])
    static let sb = Court(name: "ADS Sabak Bernam", branch: "Sabak Bernam", address: "Gelanggang Komuniti Seksyen Lapan (8), Sabak Bernam", image: "", gallery: [Gallery(image: "gal_2")])
}

extension Array where Element == Court {
    func uniqueCategories() -> [String] {
        var uniqueCategories = [String]()
        for court in self {
            for type in court.type {
                if !uniqueCategories.contains(type) {
                    uniqueCategories.append(type)
                }
            }
        }
        return uniqueCategories
    }
    func uniqueLocation() -> [String] {
        var uniqueLocation = [String]()
        for court in self {
            if !uniqueLocation.contains(court.branch) {
                uniqueLocation.append(court.branch)
            }
        }
        return uniqueLocation
    }
    func allCourt() -> [String] {
        var courts = [String]()
        for court in self {
            if !courts.contains(court.name) {
                courts.append(court.name)
            }
        }
        return courts
    }
    func courtInLocation(_ location: String) -> Court {
        return first(where: { $0.branch == location } )!
    }
}

struct Gallery: Identifiable {
    var id = UUID()
    var image: String = ""
}

extension Gallery: Encodable, Decodable, Hashable {}

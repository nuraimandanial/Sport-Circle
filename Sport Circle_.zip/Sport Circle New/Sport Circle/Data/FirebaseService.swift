//
//  FirebaseService.swift
//  Sport Circle
//
//  Created by kinderBono on 31/12/2023.
//

import Foundation
import Firebase
import FirebaseFirestore
import Combine

class FirebaseService {
    private let db = Firestore.firestore()
    
    func addUser(_ user: User) {
        do {
            let userJSON = try JSONEncoder().encode(user)
            let documentReference = db.collection("users").document(user.id.uuidString)
            documentReference.setData(["data" : userJSON, "userID" : user.id.uuidString])
        } catch {
            print("Error encoding new user: \(error)")
        }
    }
    
    func fetchAllUsers(completion: @escaping ([User]) -> Void) {
        db.collection("users").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching all user: \(error)")
                completion([])
            } else {
                var users: [User] = []
                for document in querySnapshot!.documents {
                    if let data = document.data()["data"] as? Data,
                        let userID = document.data()["userID"] as? String {
                        do {
                            var userData = try JSONDecoder().decode(User.self, from: data)
                            userData.profile.id = UUID(uuidString: document.documentID) ?? UUID(uuidString: userID) ?? userData.profile.id
                            users.append(userData)
                        } catch {
                            print("Error decoding user: \(error)")
                        }
                    }
                }
                completion(users)
            }
        }
    }
    
    func updateUser(_ user: User, completion: @escaping (Bool) -> Void) {
        do {
            let userJSON = try JSONEncoder().encode(user)
            let documentReference = db.collection("users").document(user.id.uuidString)
            documentReference.setData(["data" : userJSON, "userID" : user.id.uuidString], merge: true) { error in
                if let error = error {
                    print("Error updating user: \(error)")
                    completion(false)
                } else {
                    completion(true)
                }
            }
        } catch {
            print("Error encoding user: \(error)")
            completion(false)
        }
    }
    
    func updateMultipleUser(_ users: [User], completion: @escaping (Bool) -> Void) {
        var successCount = 0
        
        for user in users {
            updateUser(user) { success in
                if success {
                    successCount += 1
                    if successCount == users.count {
                        completion(true)
                    }
                } else {
                    completion(false)
                    return
                }
            }
        }
    }
    
    func deleteUser(_ user: User, completion: @escaping (Bool) -> Void) {
        let documentReference = db.collection("users").document(user.id.uuidString)
        documentReference.delete { error in
            if let error = error {
                print("Error deleting user: \(error)")
                completion(false)
            } else {
                print("User deleted successfully")
                completion(true)
            }
        }
    }
    
    func addCircle(_ circle: Circles) {
        do {
            let circleJSON = try JSONEncoder().encode(circle)
            let documentReference = db.collection("circles").document(circle.id.uuidString)
            documentReference.setData(["data" : circleJSON, "circleID" : circle.id.uuidString])
        } catch {
            print("Error encoding new circle: \(error)")
        }
    }
    
    func fetchAllCircles(completion: @escaping ([Circles]) -> Void) {
        db.collection("circles").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching all circles: \(error)")
                completion([])
            } else {
                var circles: [Circles] = []
                for document in querySnapshot!.documents {
                    if let data = document.data()["data"] as? Data,
                        let circleID = document.data()["circleID"] as? String {
                        do {
                            var circle = try JSONDecoder().decode(Circles.self, from: data)
                            circle.chat.id = UUID(uuidString: document.documentID) ?? UUID(uuidString: circleID) ?? circle.chat.id
                            circles.append(circle)
                        } catch {
                            print("Error decoding circle: \(error)")
                        }
                    }
                }
                completion(circles)
            }
        }
    }
    
    func updateCircle(_ circle: Circles, completion: @escaping (Bool) -> Void) {
        do {
            let circleJSON = try JSONEncoder().encode(circle)
            let documentReference = db.collection("circles").document(circle.id.uuidString)
            documentReference.setData(["data" : circleJSON, "circleID" : circle.id.uuidString], merge: true) { error in
                if let error = error {
                    print("Error updating circle: \(error)")
                    completion(false)
                } else {
                    completion(true)
                }
            }
        } catch {
            print("Error encoding circle: \(error)")
            completion(false)
        }
    }
    
    func deleteCircle(_ circle: Circles, completion: @escaping (Bool) -> Void) {
        let documentReference = db.collection("circles").document(circle.id.uuidString)
        documentReference.delete { error in
            if let error = error {
                print("Error deleting circle: \(error)")
                completion(false)
            } else {
                print("Circle deleted successfully")
                completion(true)
            }
        }
    }
    
    func addBooking(_ booking: Booking) {
        do {
            let bookingJSON = try JSONEncoder().encode(booking)
            let documentReference = db.collection("bookings").document(booking.id.uuidString)
            documentReference.setData(["data" : bookingJSON, "bookingID" : booking.id.uuidString])
        } catch {
            print("Error encoding booking data: \(error)")
        }
    }
    
    func fetchAllBookings(completion: @escaping ([Booking]) -> Void) {
        db.collection("bookings").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching all bookings: \(error)")
                completion([])
            } else {
                var bookings: [Booking] = []
                for document in querySnapshot!.documents {
                    if let data = document.data()["data"] as? Data,
                        let bookingID = document.data()["bookingID"] as? String {
                        do {
                            var booking = try JSONDecoder().decode(Booking.self, from: data)
                            booking.id = UUID(uuidString: document.documentID) ?? UUID(uuidString: bookingID) ?? UUID()
                            bookings.append(booking)
                        } catch {
                            print("Error decoding booking data: \(error)")
                        }
                    }
                }
                completion(bookings)
            }
        }
    }
    
    func deleteBooking(_ booking: Booking, completion: @escaping (Bool) -> Void) {
        let documentReference = db.collection("bookings").document(booking.id.uuidString)
        documentReference.delete { error in
            if let error = error {
                print("Error deleting booking: \(error)")
                completion(false)
            } else {
                print("Booking deleted successfully")
                completion(true)
            }
        }
    }
}

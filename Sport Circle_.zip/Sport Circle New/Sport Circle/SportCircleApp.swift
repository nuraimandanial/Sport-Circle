//
//  SportCircleApp.swift
//  Sport Circle
//
//  Created by kinderBono on 01/12/2023.
//

import SwiftUI
import Firebase

@main
struct SportCircleApp: App {
    @StateObject var appModel = AppModel()
    @AppStorage("isFirstTime") var isFirstTime: Bool = true
    
    @State var splash = true
    
    init() {
        UITabBar.appearance().backgroundColor = UIColor.init(Color.blues)
        UITabBar.appearance().unselectedItemTintColor = UIColor.init(Color.bieges)
        UITabBar.appearance().barTintColor = UIColor.init(Color.blues)
        UITableView.appearance().backgroundColor = UIColor.init(Color.bieges)
        
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                if splash {
                    if isFirstTime {
                        OnBoardingScreen(dismiss: $splash)
                            .onDisappear {
                                UserDefaults.standard.set(false, forKey: "isFirstTime")
                            }
                    } else {
                        SplashScreen()
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    splash = false
                                }
                            }
                    }
                } else {
                    if appModel.goToLogin {
                        Login()
                            .environmentObject(appModel)
                    } else {
                        if appModel.isLoggedIn {
                            if appModel.data.current_user.isAdmin {
                                AdminView()
                                    .environmentObject(appModel)
                                    .onDisappear {
                                        appModel.goToLogin = true
                                    }
                            } else {
                                UserView()
                                    .environmentObject(appModel)
                                    .onDisappear {
                                        appModel.goToLogin = true
                                    }
                            }
                        } else {
                            UserView()
                                .environmentObject(appModel)
                        }
                    }
                }
            }
            .tint(.accent)
        }
        .environment(\.colorScheme, .light)
    }
}
